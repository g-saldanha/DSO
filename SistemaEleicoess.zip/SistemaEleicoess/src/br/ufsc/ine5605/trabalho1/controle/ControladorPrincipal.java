/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.apresentacao.TelaPrincipal;

/**
 *
 * @author 09822000995
 */
public class ControladorPrincipal {
    
    private static ControladorPrincipal instance;
    
    private TelaPrincipal telaPrincipal;
    private ControladorEleitor controladorEleitor;
    private ControladorCandidato controladorCandidato;
    private ControladorUrna controladorUrna;
    private ControladorVotacao controladorVotacao;
    
    private ControladorPrincipal() {        
        this.controladorEleitor = new ControladorEleitor(this);
        this.controladorCandidato = new ControladorCandidato(this);
        this.controladorVotacao = new ControladorVotacao(this);
    }   
    
    public static ControladorPrincipal getIntance(){
        if(instance == null)
            instance = new ControladorPrincipal();
        
        return instance;
    }
    
    public void inicia(){
        this.telaPrincipal = new TelaPrincipal(this);
    }
    public void exibeTelaInicial(){
        this.telaPrincipal.setVisible(true);
    }
    public void exibeTelaEleitor() {
        controladorEleitor.exibeTelaEleitor();
    }
//    
    public void exibeTelaCandidato() {
        controladorCandidato.exibeTelaCandidato();
    }
    public void exibeTelaUrna() {
        controladorUrna.exibeTelaUrna();
    }
    public void exibeTelaVotacao(){
        //controladorVotacao.exibeTelaVotacao();
    }
    public ControladorVotacao getControladorVotacao(){
        return this.controladorVotacao;
    }

    public ControladorEleitor getControladorEleitor() {
        return controladorEleitor;
    }

    public ControladorCandidato getControladorCandidato() {
        return controladorCandidato;
    }
    
    public ControladorUrna getControladorUrna() {
        return controladorUrna;
    }

    public void iniciaVotacao() {
        this.controladorVotacao.exibeTelaInserirTitulo();
    }

   
}
