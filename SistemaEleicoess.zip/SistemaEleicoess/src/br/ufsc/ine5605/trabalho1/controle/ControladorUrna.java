/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.apresentacao.TelaCadastroUrna;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaListaUrna;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaUrna;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Urna;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author 09822000995
 */
public class ControladorUrna implements java.io.Serializable {
    
    private ControladorPrincipal owner;
    private TelaUrna telaUrna;
    private TelaCadastroUrna telaCadastroUrna;
    private TelaListaUrna telaListaUrna;
    private MapeadorUrna mapeadorUrna;
    
    ControladorUrna(ControladorPrincipal owner) {
        this.owner = owner;
        this.mapeadorUrna = new MapeadorUrna();
    }
    
    public void exibeTelaUrna() {
        this.telaUrna = new TelaUrna(this);
        telaUrna.setVisible(true);
    } 
    
    public void exibeTelaCadastroUrna(){
        this.telaCadastroUrna = new TelaCadastroUrna(this);
        telaCadastroUrna.setVisible(true);
    }
    
    public void cadastroAutomaticoDeUrnas(){
        
    }
    
    
    public ControladorPrincipal getOwner() {
        return owner;
    }
        
    public HashMap<Integer, Urna> getUrnas() {
        return this.mapeadorUrna.getUrnas();
    }

    public void voltar(){      
        this.telaUrna.setVisible(false);
        owner.exibeTelaInicial();
    }
    
    public void listarUrnas(){
        this.telaListaUrna = new TelaListaUrna(this);
        telaListaUrna.setVisible(true);
    }
    
    public void cadastraUrna(Integer codigo) throws CadastroIncorretoException{
        if(codigo == null)
            throw new CadastroIncorretoException("Codigo vazio!");      
        if(this.mapeadorUrna.getUrnas().containsKey(codigo))
             throw new CadastroIncorretoException("Codigo de eleitor existente!") ;

        Urna novaUrna = new Urna(codigo);
                
        this.mapeadorUrna.put(novaUrna);
        
    }
    
    
    
    public void alteraUrna(Urna urna){
      this.mapeadorUrna.altera(urna);
    }
    
    
    
    
    public void excluiUrna(Urna urna){
        this.mapeadorUrna.remove(urna);
    }

   
    
    
}
