/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;


import br.ufsc.ine5605.trabalho1.entidade.Urna;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Caio
 */
class MapeadorUrna {
    
    private HashMap <Integer, Urna> cacheUrnas  = new HashMap<>();
    private final String filename = "urnas.ele";
    
    public MapeadorUrna(){
        try {
            FileInputStream fIn = new  FileInputStream(filename); // tenta abrir fluxo de dados
            fIn.close();
        } catch (FileNotFoundException ex) {
            // Se deu ruim
            new File(this.filename);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.load();
    }

    public void put(Urna urna) {
        this.cacheUrnas.put(urna.getCodigo(), urna);
        this.persist();
    }
    
    public Urna get(Integer idUrna) {
        return (Urna) this.cacheUrnas.get(idUrna);
    }
    
    public void altera(Urna urna){
        this.cacheUrnas.replace(urna.getCodigo(), urna);
        this.persist();
    }
    
    public void remove (Urna urna){
        this.cacheUrnas.remove(urna.getCodigo(), urna);
        this.persist();
    }
    
    
        public void persist(){
        try{
            FileOutputStream fOutStream = new FileOutputStream(filename);
            ObjectOutputStream obOutStream = new ObjectOutputStream(fOutStream);
            
            obOutStream.writeObject(this.cacheUrnas);
            
            obOutStream.flush();
            fOutStream.flush();
            
            obOutStream.close();
            fOutStream.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        }
    } 
        
    
    public void load(){
        try {
            FileInputStream fIn = new  FileInputStream(filename);
            ObjectInputStream oIn = new ObjectInputStream(fIn);
        
            this.cacheUrnas = (HashMap<Integer, Urna>) oIn.readObject();
        
            oIn.close();
            fIn.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(MapeadorUrna.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public HashMap<Integer, Urna> getUrnas(){
        return this.cacheUrnas;
    }
    
}
