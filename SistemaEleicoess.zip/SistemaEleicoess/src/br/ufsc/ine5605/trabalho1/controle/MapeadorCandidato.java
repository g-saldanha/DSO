/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 09822000995
 */
public class MapeadorCandidato {

    private HashMap <Integer, Cidadao> cacheCandidatos  = new HashMap<>();            
    private final String filename = "candidatos.can";
    
    public MapeadorCandidato(){
        try {
            FileInputStream fIn = new  FileInputStream(filename); // tenta abrir fluxo de dados
            fIn.close();
        } catch (FileNotFoundException ex) {
            // Se deu ruim
            new File(this.filename);
            this.persist();
        } catch (IOException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.load();
    }
    
    public Candidato get(Integer idCandidato){
        return (Candidato) cacheCandidatos.get(idCandidato);
    }
    
    public void put (Candidato candidato){
        cacheCandidatos.put(candidato.getCodigo(), candidato);
        this.persist();
    }
    
    public void altera(Candidato candidato){
        this.cacheCandidatos.replace(candidato.getCodigo(), candidato);
        this.persist();
    }
    
    public void remove (Candidato eleitor){
        this.cacheCandidatos.remove(eleitor.getCodigo(), eleitor);
        this.persist();
    }
    
    public void persist(){
        try{
            FileOutputStream fOutStream = new FileOutputStream(filename);
            ObjectOutputStream obOutStream = new ObjectOutputStream(fOutStream);
            
            obOutStream.writeObject(this.cacheCandidatos);
            
            obOutStream.flush();
            fOutStream.flush();
            
            obOutStream.close();
            fOutStream.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapeadorCandidato.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorCandidato.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void load(){
        try {
            FileInputStream fIn = new  FileInputStream(filename);
            ObjectInputStream oIn = new ObjectInputStream(fIn);
        
            this.cacheCandidatos = (HashMap<Integer, Cidadao>) oIn.readObject();
        
            oIn.close();
            fIn.close();
            
        } catch (FileNotFoundException ex) {            
            Logger.getLogger(MapeadorCandidato.class.getName()).log(Level.SEVERE, null, ex);
            //new File(this.filename);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorCandidato.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MapeadorCandidato.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    public HashMap<Integer, Cidadao> getCandidatos() {
        return this.cacheCandidatos;
    }
}
