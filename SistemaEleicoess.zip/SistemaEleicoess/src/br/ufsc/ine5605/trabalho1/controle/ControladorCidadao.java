/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.exception.AlteracaoIncorretaException;
import br.ufsc.ine5605.trabalho1.interfaces.IControladorCidadao;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Eduardo
 */
public class ControladorCidadao implements IControladorCidadao {

    @Override
    public void cadastraCidadao(int codigo, String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
    public <T> void alteraCidadao(Cidadao cidadao, T alteracao) throws AlteracaoIncorretaException {
        
        if (alteracao instanceof String) //Se a alteracao é uma String
            cidadao.setNome((String) alteracao); //Altera o nome do candidato
    }

    @Override
    public void excluiCidadao(Cidadao cidadao, ArrayList<Cidadao> listaCidadaos) {
        if(cidadao != null && listaCidadaos.contains(cidadao))
            listaCidadaos.remove(cidadao);        
    }

    @Override
    public void exibeCidadaosCadastrados() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void exibeTelaCidadao() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public <T> Cidadao buscaCidadao(T informacao, ArrayList<Cidadao>listaCidadaos) throws AlteracaoIncorretaException {
        if (informacao instanceof String){
            for(Cidadao cidadao : listaCidadaos){
                if(cidadao.getNome() == informacao && cidadao != null)
                    return cidadao;
            }
        }
        throw new AlteracaoIncorretaException();
    }    
 
}
