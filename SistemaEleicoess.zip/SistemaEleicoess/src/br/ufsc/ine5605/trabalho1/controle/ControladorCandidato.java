 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.Enum.Cargo;
import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.Enum.Partido;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaCadastroCandidato;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaCandidato;
import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.exception.AlteracaoIncorretaException;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Eduardo
 */
public class ControladorCandidato extends ControladorCidadao {
    
    private final ControladorPrincipal owner;
    private TelaCandidato telaCandidato;
    private TelaCadastroCandidato telaCadastroCandidato;
    
    //private ArrayList<Cidadao> candidatos;
    private MapeadorCandidato mapeadorCandidato;
    
    private ArrayList<Cidadao> candidatosAPrefeitoDeFlorianopolis;
    private ArrayList<Cidadao> candidatosAVereadorDeFlorianopolis;
    private ArrayList<Cidadao> candidatosAPrefeitoDeSaoJose;
    private ArrayList<Cidadao> candidatosAVereadorDeSaoJose;
        
    public ControladorCandidato (ControladorPrincipal owner) {
        this.owner = owner;       
        this.mapeadorCandidato = new MapeadorCandidato();
    }
    
    public void cadastroAutomaticoDeCandidato(){
        this.mapeadorCandidato.put(new Candidato(101, "Gean Loureiro", Partido.PMDB, Cidade.FLORIANOPOLIS, Cargo.PREFEITO));
        this.candidatosAPrefeitoDeFlorianopolis.add(new Candidato(102, "Angela Amim", Partido.PP, Cidade.FLORIANOPOLIS, Cargo.PREFEITO));
    }
    
    public ControladorPrincipal getOwner() {
        return owner;
    }
    
    public void cadastraCandidato(Integer codigo, String nome, Partido partido) throws AlteracaoIncorretaException, CadastroIncorretoException{
       if(codigo == null)
            throw new CadastroIncorretoException("Codigo vazio!");      
        if(this.mapeadorCandidato.getCandidatos().containsKey(codigo))
             throw new CadastroIncorretoException("Codigo de eleitor existente!") ;
        if(nome.isEmpty())
            throw new CadastroIncorretoException("Nome vazio!");
        
        Candidato novoCandidato = new Candidato(codigo, nome, partido);
        
        this.mapeadorCandidato.put(novoCandidato);
        
        System.out.println(novoCandidato.getNome());
        System.out.println(novoCandidato.getPartido().getNumeroPartido());
        System.out.println(novoCandidato.getCodigo());
    }
   
    public void alteraCandidato(Candidato candidato) {
        this.mapeadorCandidato.altera(candidato);
    }
    
    public void excluiCandidato(Candidato candidato){          
        this.mapeadorCandidato.remove(candidato);
    }

    public void exibeTelaCandidato() {
        this.telaCandidato = new TelaCandidato(this);
        telaCandidato.setVisible(true);
    }


    public void exibeTelaCadastroCandidato() {
        this.telaCadastroCandidato = new TelaCadastroCandidato(this);
        telaCadastroCandidato.setVisible(true);
    }

    public HashMap<Integer, Cidadao> getCandidatos() {
        return this.mapeadorCandidato.getCandidatos();
    }

    public void voltar() {
        this.telaCandidato.setVisible(false);
        owner.exibeTelaInicial();
    }   
}

