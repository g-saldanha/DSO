/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaCadastroEleitor;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaEleitor;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaListaEleitor;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.exception.AlteracaoIncorretaException;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/**
 *
 * @author 09822000995
 */
public class ControladorEleitor extends ControladorCidadao implements java.io.Serializable{
    private final ControladorPrincipal owner;
    private TelaEleitor telaEleitor;
    private TelaCadastroEleitor telaCadastroEleitor;
    private TelaListaEleitor telaListaEleitor;
    private MapeadorEleitor mapeadorEleitor;

    ControladorEleitor(ControladorPrincipal owner) {
        this.owner = owner;            
        this.mapeadorEleitor = new MapeadorEleitor();
        
        //this.cadastroAutomaticoDeEleitores();
    }
    public void exibeTelaEleitor() {
        this.telaEleitor = new TelaEleitor(this);
        telaEleitor.setVisible(true);
    }  
    public void exibeTelaCadastroEleitor(){
        this.telaCadastroEleitor = new TelaCadastroEleitor(this);
        telaCadastroEleitor.setVisible(true);
    }
    public void cadastroAutomaticoDeEleitores(){        
        this.mapeadorEleitor.put(new Eleitor(1, "1234", "Du", Cidade.FLORIANOPOLIS));
        this.mapeadorEleitor.put(new Eleitor(2, "2234", "Dudu", Cidade.FLORIANOPOLIS));
        this.mapeadorEleitor.put(new Eleitor(3, "3234", "Edu", Cidade.FLORIANOPOLIS));
        this.mapeadorEleitor.put(new Eleitor(4, "4234", "ED", Cidade.FLORIANOPOLIS));
        this.mapeadorEleitor.put(new Eleitor(5, "1235", "Eddie", Cidade.FLORIANOPOLIS));
        
    }
    
    public ControladorPrincipal getOwner() {
        return owner;
    }
    public HashMap<Integer, Cidadao> getEleitores() {
        return this.mapeadorEleitor.getEleitores();
    }
    public void voltar(){      
        this.telaEleitor.setVisible(false);
        owner.exibeTelaInicial();
    }
 
    public void listarEleitores(){
        this.telaListaEleitor = new TelaListaEleitor(this);
        telaListaEleitor.setVisible(true);
    }
    
    public void cadastraEleitor(Integer codigo, String tituloDeEleitor, String nome) throws CadastroIncorretoException{
        if(codigo == null)
            throw new CadastroIncorretoException("Codigo vazio!");      
        if(this.mapeadorEleitor.getEleitores().containsKey(codigo))
             throw new CadastroIncorretoException("Codigo de eleitor existente!") ;
        if(nome.isEmpty())
            throw new CadastroIncorretoException("Nome vazio!");
        if(tituloDeEleitor.isEmpty())
            throw new CadastroIncorretoException("Titulo de eleitor vazio!") ;
        
        verificaTitulo(tituloDeEleitor);
            
        Eleitor novoEleitor = new Eleitor(codigo, tituloDeEleitor, nome);
                
        this.mapeadorEleitor.put(novoEleitor);
        
    }
    
    public void verificaTitulo(String tituloDeEleitor) throws CadastroIncorretoException{
        Set<Integer> keySet = this.mapeadorEleitor.getEleitores().keySet();
        for(Integer key : keySet){
            if(this.mapeadorEleitor.get(key).getTituloDeEleitor().equals(tituloDeEleitor)){
                 throw new CadastroIncorretoException("Titulo de eleitor existente!") ;
            }
        }
    } 

    public void alteraEleitor(Eleitor eleitor){
      this.mapeadorEleitor.altera(eleitor);
    }
  
    public void excluiEleitor(Eleitor eleitor){
        this.mapeadorEleitor.remove(eleitor);
    }
   
}

