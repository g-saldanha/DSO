/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;


import br.ufsc.ine5605.trabalho1.Enum.Cargo;
import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaInserirTitulo;
import br.ufsc.ine5605.trabalho1.apresentacao.TelaVotacao;
import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import br.ufsc.ine5605.trabalho1.entidade.SecaoEleitoral;
import java.util.ArrayList;
import br.ufsc.ine5605.trabalho1.entidade.ZonaEleitoral;
import br.ufsc.ine5605.trabalho1.exception.TituloInvalidoException;
import br.ufsc.ine5605.trabalho1.exception.VotoInvalidoException;
import br.ufsc.ine5605.trabalho1.exception.naoHaVencedorException;


/**
 *
 * @author 09822000995
 */
public class ControladorVotacao {
    
    private ArrayList<ZonaEleitoral> zonasEleitorais;
    
    private ArrayList<Cidadao> candidatosAPrefeitoDeFlorianopolis;
    private ArrayList<Cidadao> candidatosAVereadorDeFlorianopolis;
    private ArrayList<Cidadao> candidatosAPrefeitoDeSaoJose;
    private ArrayList<Cidadao> candidatosAVereadorDeSaoJose;
    
    private ArrayList<Cidadao> eleitoresFlorianopolis;    
    private ArrayList<Cidadao> eleitoresSaoJose;    
    
    private final ControladorPrincipal owner;
    private TelaVotacao telaVotacao;
    private TelaInserirTitulo telaInserirTitulo;
    
    ControladorVotacao (ControladorPrincipal owner){
        this.owner = owner;      
        this.telaVotacao = new TelaVotacao(this);
        this.zonasEleitorais = new ArrayList<>();
        this.adicionarCidadaosCadastrados();
    }

    public void exibeTelaVotacao() {
        telaVotacao.exibeTelaVotacao();
    }
    
    public void iniciaVotacao(){        
        zonasEleitorais.add(new ZonaEleitoral(this, 1, Cidade.FLORIANOPOLIS, this.eleitoresFlorianopolis, this.candidatosAPrefeitoDeFlorianopolis, this.candidatosAVereadorDeFlorianopolis));
        zonasEleitorais.add(new ZonaEleitoral(this, 2, Cidade.SAOJOSE, this.eleitoresSaoJose, this.candidatosAPrefeitoDeSaoJose, this.candidatosAVereadorDeSaoJose));
        this.exibeTelaVotacao();
    }
    public void adicionarCidadaosCadastrados(){
        //this.candidatosAPrefeitoDeFlorianopolis = owner.getControladorCandidato().getCandidatosAPrefeitoDeFlorianopolis();
         
    }

    public TelaVotacao getTelaVotacao() {
        return telaVotacao;
    }
    
    public ArrayList<ZonaEleitoral> getZonasEleitorais() {
        return zonasEleitorais;
    }

    public ControladorPrincipal getOwner() {
        return owner;
    }
    
    public void exibeZonasEleitoraisCadastradas(){
        for(ZonaEleitoral zona : this.zonasEleitorais){
            telaVotacao.exibeInfoZonaEleitoral(zona);
        }
    }
    public void exibeCidadaosCadastrados(){
        for(Cidadao eleitor : this.eleitoresFlorianopolis){
            telaVotacao.exibeInfoEleitor((Eleitor) eleitor);
        }
        for(Cidadao eleitor : this.eleitoresSaoJose){
            telaVotacao.exibeInfoEleitor((Eleitor) eleitor);
        }
    }

    public ZonaEleitoral selecionaZonaEleitoral(int opcao) {
        for(ZonaEleitoral zona : this.getZonasEleitorais()){
            if(zona.getCodigo() == opcao)
                return zona;
        }
        return null;
    }    

    public void exibeSecoesEleitoraisCadastradas(ZonaEleitoral zona) {
        for(SecaoEleitoral secao : zona.getSecoesEleitorais())
            this.telaVotacao.exibeInfoSecaoEleitoral(secao);
    }

    public SecaoEleitoral selecionaSecaoEleitoral(ZonaEleitoral zona, int opcao) {
        for(SecaoEleitoral secao : zona.getSecoesEleitorais()){
            if(secao.getCodigo() == opcao)
                return secao;
        }
        return null;
    }
    
    public void exibeEleitoresCadastradosNaUrna(SecaoEleitoral secao){
        for(Cidadao eleitor : secao.getUrna().getEleitores()){
            this.telaVotacao.exibeInfoEleitor(eleitor);
        }
    }

    public Eleitor verificarTituloDeEleitor(String tituloDeEleitor, SecaoEleitoral secao) throws TituloInvalidoException{ 
        for(Cidadao eleitor : secao.getUrna().getEleitores()){
            Eleitor eleitorTeste = (Eleitor) eleitor; 
            if(eleitorTeste.getTituloDeEleitor().equals(tituloDeEleitor)){
                if(secao.getUrna().getEleitoresQueVotaram().contains(eleitorTeste)){
                    throw new TituloInvalidoException("Esse eleitor ja votou");
                }
                return eleitorTeste;
            }
        }                    
        throw new TituloInvalidoException("Titulo invalido"); //To change body of generated methods, choose Tools | Templates.
    }

    public void trataVoto(SecaoEleitoral secao, int voto, Eleitor eleitor, int codigoCargo) throws VotoInvalidoException {
        
        if(voto > 0 && voto < 100){
            if(Cargo.PREFEITO.getCodigo() == codigoCargo){
                Candidato candidato = this.verificarCandidatoAPrefeito(secao, voto);
                if(candidato != null){
                    this.addVoto(candidato, eleitor, secao);
                }
                else if(voto == 0){
                    secao.getUrna().addVotoBrancoPrefeito();
                    telaVotacao.mensagemVotoBranco();
                }  
                else{
                    secao.getUrna().addVotoNuloPrefeito();
                }
                telaVotacao.telaMostraCandidatoVotado(candidato);
            }
            else if(Cargo.VEREADOR.getCodigo() == codigoCargo){
                Candidato candidato = this.verificarCandidatoAPrefeito(secao, voto);
                if(candidato != null){
                    this.addVoto(candidato, eleitor, secao);
                }
                else if(voto == 0){
                    secao.getUrna().addVotoBrancoVereador();
                    telaVotacao.mensagemVotoBranco();
                }
                else{
                    secao.getUrna().addVotoNuloVereador();                    
                }
                telaVotacao.telaMostraCandidatoVotado(candidato);
            }
        }    
        else{
            throw new VotoInvalidoException(); 
        }
    }
    public Candidato verificarCandidatoAPrefeito(SecaoEleitoral secao, int numeroPartido) {         
        for(Cidadao candidato : secao.getUrna().getCandidatosAPrefeito() ){
            Candidato candidatoAPrefeito = (Candidato) candidato;            
            if(candidatoAPrefeito.getPartido().getNumeroPartido() == numeroPartido){
                return candidatoAPrefeito;
            }
        }
        return null;
    }

    public Candidato verificarCandidatoAVereador(SecaoEleitoral secao, int numeroPartido) {
        Candidato candidatoAVereador = (Candidato) this.encontraCandidatoPeloNumero(numeroPartido, secao.getUrna().getCandidatosAVereador());
            if(candidatoAVereador != null ){
                return candidatoAVereador;
            }        
        return null;
    }
    public Cidadao encontraEleitorPeloTitulo(String tituloDeEleitor, ArrayList<Cidadao> eleitores){
        for(Cidadao eleitor : eleitores){
            Eleitor eleitorDoTitulo = (Eleitor) eleitor;
            if(eleitorDoTitulo.getTituloDeEleitor().equals(tituloDeEleitor)){
                return eleitor;
            }
        }
        return null;
    }
    public Cidadao encontraCandidatoPeloNumero(int numeroDoPartido, ArrayList<Cidadao> candidatos){
        for(Cidadao candidato : candidatos){
            Candidato candidatoDoNumero = (Candidato) candidato;
            if(candidatoDoNumero.getPartido().getNumeroPartido() == numeroDoPartido){
                return candidato;
            }
        }
        return null;
    }

    public void addVoto(Candidato prefeito, Eleitor eleitor, SecaoEleitoral secao) {
        secao.addVoto(eleitor, prefeito);
    }    

    public void contabilizarVotosEleicao(int codigoCidade, int codigoCargo) {
        Cidade cidade = null; 
        switch(codigoCidade){
            case 1:
                cidade = Cidade.FLORIANOPOLIS; 
                break;
            case 2:
                cidade = Cidade.SAOJOSE;
                break;
            default:
                return;            
        }
        if(cidade != null){ 
            for(ZonaEleitoral zona : this.zonasEleitorais){                
                if(zona.getCidade() == cidade){
                    zona.contabilizaVotosDasSecoes(codigoCargo);
                    zona.informaVotosDasSecoes(codigoCargo);
                }
            }
        }
    }

    public void calcularTotais(){
        for(ZonaEleitoral zona : this.zonasEleitorais){
            zona.contabilizaVotosDasSecoes(1);
            Candidato vencedor = (Candidato) zona.informaCandidatoVencedor(zona.getTotalVotosPrefeito(), zona.getCandidatosAPrefeito());
            if(vencedor != null)
                telaVotacao.telaMostraVencedore(vencedor);
            else{
                telaVotacao.mensagemNaoHaVencedor(zona.getCidade());
            }
        }
    }
    

    public void exibeTelaInserirTitulo() {
        this.telaInserirTitulo = new TelaInserirTitulo(this);
        this.telaInserirTitulo.setVisible(true);
    }

    public void validarTitulo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
