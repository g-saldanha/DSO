/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.controle;

import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public class MapeadorEleitor implements java.io.Serializable{
    
    private HashMap <Integer, Cidadao> cacheEleitores  = new HashMap<>(); 
    private final String filename = "eleitores.ele";
    
    public MapeadorEleitor(){
        try {
            FileInputStream fIn = new  FileInputStream(filename); // tenta abrir fluxo de dados
            fIn.close();
        } catch (FileNotFoundException ex) {
            // Se deu ruim
            new File(this.filename);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.load();
    }
    
    public Eleitor get(Integer idEleitor){
        return (Eleitor) this.cacheEleitores.get(idEleitor);
    }
    
    public void put (Eleitor eleitor){
        this.cacheEleitores.put(eleitor.getCodigo(), eleitor);
        this.persist();
    }
    
    public void altera(Eleitor eleitor){
        this.cacheEleitores.replace(eleitor.getCodigo(), eleitor);
        this.persist();
    }
    
    public void remove (Eleitor eleitor){
        this.cacheEleitores.remove(eleitor.getCodigo(), eleitor);
        this.persist();
    }
    
    public void persist(){
        try{
            FileOutputStream fOutStream = new FileOutputStream(filename);
            ObjectOutputStream obOutStream = new ObjectOutputStream(fOutStream);
            
            obOutStream.writeObject(this.cacheEleitores);
            
            obOutStream.flush();
            fOutStream.flush();
            
            obOutStream.close();
            fOutStream.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void load(){
        try {
            FileInputStream fIn = new  FileInputStream(filename);
            ObjectInputStream oIn = new ObjectInputStream(fIn);
        
            this.cacheEleitores = (HashMap<Integer, Cidadao>) oIn.readObject();
        
            oIn.close();
            fIn.close();
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        }catch (ClassNotFoundException ex) {
            Logger.getLogger(MapeadorEleitor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public HashMap<Integer, Cidadao> getEleitores(){
        return this.cacheEleitores;
    }
}





