/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import java.util.ArrayList;

/**
 *
 * @author 09822000995
 */
public class Votacao {
    
    private ArrayList<ZonaEleitoral> zonasEleitorais;

    public Votacao(ArrayList<ZonaEleitoral> zonasEleitorais) {
        this.zonasEleitorais = zonasEleitorais;
    }
    
    
    
    
}
