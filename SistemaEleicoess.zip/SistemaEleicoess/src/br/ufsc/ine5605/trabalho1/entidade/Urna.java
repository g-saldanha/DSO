/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import br.ufsc.ine5605.trabalho1.controle.ControladorEleitor;
import java.util.ArrayList;

/**
 *
 * @author Eduardo
 */
public class Urna {
    
    private ArrayList<Cidadao> candidatosAPrefeito;  
    private ArrayList<Cidadao> candidatosVotadosAPrefeito;  
    private ArrayList<Cidadao> candidatosAVereador;  
    private ArrayList<Cidadao> candidatosVotadosAVereador;  
    private ArrayList<Cidadao> eleitores;
    private ArrayList<Cidadao> eleitoresQueVotaram;
    private SecaoEleitoral owner;
    
    private int codigo;
    private int votosBrancoVereador;
    private int votosBrancoPrefeito;
    private int votosNuloVereador;
    private int votosNuloPrefeito;
    //private int quantidadeEleitores = 0;
    

    public Urna(SecaoEleitoral owner,  ArrayList<Cidadao> eleitores, ArrayList<Cidadao> candidatosAPrefeito, ArrayList<Cidadao> candidatosAVereador, int codigo) {
        this.owner = owner;
        this.candidatosAPrefeito = candidatosAPrefeito;
        this.candidatosVotadosAPrefeito = new ArrayList<>();
        this.candidatosVotadosAVereador = new ArrayList<>();
        this.eleitoresQueVotaram = new ArrayList<>();
        this.candidatosAVereador = candidatosAVereador;
        this.eleitores = eleitores;
        this.codigo = codigo;
        this.votosBrancoVereador = 0;
        this.votosBrancoPrefeito = 0;
        this.votosNuloVereador = 0;
        this.votosNuloPrefeito = 0;
    }   

   

    public Urna(Integer codigo) {
        this.codigo = codigo;
    }

    public ArrayList<Cidadao> getEleitoresQueVotaram() {
        return eleitoresQueVotaram;
    }
    
    public ArrayList<Cidadao> getCandidatosVotadosAPrefeito() {
        return candidatosVotadosAPrefeito;
    }

    public ArrayList<Cidadao> getCandidatosVotadosAVereador() {
        return candidatosVotadosAVereador;
    }
    public void addVotoNuloVereador(){
        this.votosNuloVereador++;
    }
    public void addVotoNuloPrefeito(){
        this.votosNuloPrefeito++;
    }
    public void addVotoBrancoVereador(){
        this.votosBrancoVereador++;
    }
     public void addVotoBrancoPrefeito(){
        this.votosBrancoPrefeito++;
    }

    public int getVotosBrancoVereador() {
        return votosBrancoVereador;
    }

    public int getVotosBrancoPrefeito() {
        return votosBrancoPrefeito;
    }

    public int getVotosNuloVereador() {
        return votosNuloVereador;
    }

    public int getVotosNuloPrefeito() {
        return votosNuloPrefeito;
    }

  

    public ArrayList<Cidadao> getCandidatosAPrefeito() {
        return this.candidatosAPrefeito;
    }

    public ArrayList<Cidadao> getCandidatosAVereador() {
        return this.candidatosAVereador;
    }

    public ArrayList<Cidadao> getEleitores() {
        return this.eleitores;
    }

    public SecaoEleitoral getOwner() {
        return this.owner;
    }

    public int getCodigo() {
        return this.codigo;
    }
    
    /*
    public void contaVotosUrna() {
        System.out.println("votos recebidos");
        for(Candidato candidato : candidatos){
            System.out.println(candidato.getNome() + candidato.getNumeroDoPartido() + candidato.getVotosRecebidos());
        
       }
    }
    */
    
    public void contaVotosPrefeito() {
          
    }
    
    public void contaVotosVereador() {
       
    }
    /*
    public void votaCandidato(int tituloDeEleitor, int numeroCandidato) {
        Eleitor eleitor = buscaEleitor(tituloDeEleitor);
        Candidato candidato = buscaCandidato(numeroCandidato);

        if(eleitor.jaVotou() != true && numeroCandidato == 00) {
            votosBranco++; 
            eleitor.computaVoto();
        } else if(eleitor.jaVotou() != true && candidato == null) {
            votosNulo++;
            eleitor.computaVoto();
         } else if(eleitor.jaVotou() != true) {
             candidato.receberVoto();
            eleitor.computaVoto();
         }        
    }
    */
/*
    private Eleitor buscaEleitor(int tituloDeEleitor) {
        Eleitor eleitor1 = null;       
        for(Eleitor eleitor : eleitores){
            if(eleitor.getTituloDeEleitor() == tituloDeEleitor){
                eleitor1 = eleitor;
            }
        }   
        return eleitor1;
    }
  */      
  
    /*
    public Candidato buscaCandidato(int numeroCandidato) {
       Candidato candidato1 = null;       
        for(Candidato candidato : candidatos){
            if(candidato.getNumeroDoPartido() == numeroCandidato){
                candidato1 = candidato;
            }
        }   
        return candidato1;
    }
*/     

    void addVotoPrefeito(Candidato candidato) {
        this.candidatosVotadosAPrefeito.add(candidato);
    }
    void addVotoVereador(Candidato candidato) {
        this.candidatosVotadosAVereador.add(candidato);
    }
    void addEleitoresQueVotaram(Eleitor eleitor) {
        this.eleitoresQueVotaram.add(eleitor);
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
        }
        
}
