/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import java.util.ArrayList;
import java.util.ListIterator;

/**
 *
 * @author Eduardo
 */
public class SecaoEleitoral {
    private int codigo;
    private Urna urna;
    private ZonaEleitoral owner;
    private ArrayList<Object>[][] votosPrefeito;

    public SecaoEleitoral(int codigo, ArrayList<Cidadao> eleitores, ArrayList<Cidadao> candidatosAPrefeito, ArrayList<Cidadao> candidatosAVereador, ZonaEleitoral owner) {
        this.codigo = codigo;        
        this.owner = owner;
        this.votosPrefeito = new ArrayList[candidatosAPrefeito.size()][2];
        this.cadastroAutomaticoDeUrna(eleitores, candidatosAPrefeito, candidatosAVereador);
    }
   
    public void cadastroAutomaticoDeUrna(ArrayList<Cidadao> eleitores, ArrayList<Cidadao> candidatosAPrefeito, ArrayList<Cidadao> candidatosAVereador){
        this.urna = new Urna(this, eleitores, candidatosAPrefeito, candidatosAVereador, 1);
    }
        
    public void contabilizaVotos(int cargo){
        switch(cargo){
            case 1:
                this.contabilizaVotosPrefeito();
                break;
            case 2:
                this.contabilizaVotosVereador();
                break;
            default:
                return;
        }        
    }
    public int[] contabilizaVotosPrefeito(){
        int tamanhoVetorVotos = this.urna.getCandidatosAPrefeito().size();
        int[] votos = new int[ tamanhoVetorVotos ] ;
        for(Cidadao prefeito : this.urna.getCandidatosVotadosAPrefeito()){
            votos[this.urna.getCandidatosAPrefeito().indexOf(prefeito)]++;
        }
        for(int i = 0; i < votosPrefeito.length; i++){
            //owner.getOwner().getTelaVotacao().exibeVoto((Candidato) this.urna.getCandidatosAPrefeito().get(i), votos[i]);
        }
        return votos;
    }
    public void contabilizaVotosVereador() {
        int tamanhoVetorVotos = this.urna.getCandidatosAVereador().size();
        int[] votos = new int[ tamanhoVetorVotos ] ;
        for(Cidadao vereador : this.urna.getCandidatosVotadosAVereador()){
            votos[this.urna.getCandidatosAVereador().indexOf(vereador)]++;
        }        
    }
    
    public void informaVotosPrefeito(){
        int[] votosPrefeito = this.contabilizaVotosPrefeito();
        owner.getOwner().getTelaVotacao().exibeInfoSecaoEleitoral(this);
        for(int i = 0; i < votosPrefeito.length; i++){
            owner.getOwner().getTelaVotacao().exibeVoto((Candidato) this.urna.getCandidatosAPrefeito().get(i), votosPrefeito[i]);
        }
        int brancos  = this.getUrna().getVotosBrancoPrefeito();
        int nulos = this.getUrna().getVotosNuloPrefeito();
        owner.getOwner().getTelaVotacao().exibeVotosBrancosENulos(brancos, nulos);
    }
    
      
    public void addVoto(Eleitor eleitor, Candidato candidato){
        this.urna.addVotoPrefeito(candidato);
        this.urna.addEleitoresQueVotaram(eleitor);
    }

    public int getCodigo() {
        return this.codigo;
    }

    public Urna getUrna() {
        return this.urna;
    }  

    void informaVotosVereador() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
