/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.controle.ControladorVotacao;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 09822000995
 */
public class ZonaEleitoral {
    private int codigo;
    private int[] totalVotosPrefeito;
    private Cidade cidade;
    private ArrayList<SecaoEleitoral> secoesEleitorais;  
    private ArrayList<Cidadao> candidatosAPrefeito;  
    private ArrayList<Cidadao> candidatosAVereador;  
    private ControladorVotacao owner;

    public ZonaEleitoral(ControladorVotacao owner, int codigo, Cidade cidade, ArrayList<Cidadao> eleitores, ArrayList<Cidadao> candidatosAPrefeito, ArrayList<Cidadao> candidatosAVereador) {
        this.owner = owner;
        this.codigo = codigo;
        this.totalVotosPrefeito = new int[candidatosAPrefeito.size()];
        this.cidade = cidade;
        this.candidatosAPrefeito = candidatosAPrefeito;
        this.candidatosAVereador = candidatosAVereador;
        secoesEleitorais = new ArrayList<>();
        this.cadastroAutomaticoDeSecao(eleitores, candidatosAPrefeito, candidatosAVereador);
    }
    
    public void cadastroAutomaticoDeSecao(ArrayList<Cidadao> eleitores, ArrayList<Cidadao> candidatosAPrefeito, ArrayList<Cidadao> candidatosAVereador){
        ArrayList<Cidadao> eleitores1 = new ArrayList<>();
        ArrayList<Cidadao> eleitores2 = new ArrayList<>();
        for(int i = 0; i < (eleitores.size()/2); i++){
            eleitores1.add(eleitores.get(i));
        }
         for(int i = (eleitores.size()/2); i < eleitores.size(); i++){
            eleitores2.add(eleitores.get(i));
        }
        this.secoesEleitorais.add(new SecaoEleitoral(1, eleitores1, candidatosAPrefeito, candidatosAVereador, this));
        this.secoesEleitorais.add(new SecaoEleitoral(2, eleitores2, candidatosAPrefeito, candidatosAVereador, this));
    }  
    
    public void contabilizaVotosDasSecoes(int codigoCargo){
        switch(codigoCargo){
            case 1:
                this.contabilizaVotosPrefeito();
                break;
            case 2:
                this.contabilizaVotosVereador();
                break;                    
        } 
    }
    public void contabilizaVotosPrefeito(){
        for(SecaoEleitoral secao : this.secoesEleitorais){
            int[] totalVotosSecao = secao.contabilizaVotosPrefeito();
            for(int i = 0; i < this.totalVotosPrefeito.length; i++){
                this.totalVotosPrefeito[i] += totalVotosSecao[i];
            }
        }
    }
    public void informaVotosDasSecoes(int codigoCargo){
        switch(codigoCargo){
            case 1:
                for(SecaoEleitoral secao : this.secoesEleitorais)
                    secao.informaVotosPrefeito();        
                break;
            case 2:
                //for(SecaoEleitoral secao : this.secoesEleitorais)
                    //secao.informaVotosVereador();   
            break;                    
        } 
        
    }

    public ControladorVotacao getOwner() {
        return owner;
    }
    
    public int[] getTotalVotosPrefeito() {
        return totalVotosPrefeito;
    }

    public ArrayList<Cidadao> getCandidatosAPrefeito() {
        return candidatosAPrefeito;
    }

    public ArrayList<Cidadao> getCandidatosAVereador() {
        return candidatosAVereador;
    }
    
    
    public Cidadao informaCandidatoVencedor(int[] votos, ArrayList<Cidadao> candidatos){
        Cidadao candidatoVencedor = null;
        for(int i = 1; i < votos.length; i++){
            if(votos[i] > votos[i - 1]){
                if(candidatos.get(i) != null)
                    candidatoVencedor = candidatos.get(i);
            }
        }
        return candidatoVencedor;
    }

    public int getCodigo() {
        return this.codigo;
    }
    
    public Cidade getCidade() {
        return this.cidade;
    }

    public ArrayList<SecaoEleitoral> getSecoesEleitorais() {
        return secoesEleitorais;
    }

    private void contabilizaVotosVereador() {
        System.out.print("Not supported yet."); 
    }
}
