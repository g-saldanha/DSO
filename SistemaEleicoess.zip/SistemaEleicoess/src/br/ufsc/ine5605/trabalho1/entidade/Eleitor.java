/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import br.ufsc.ine5605.trabalho1.Enum.Cidade;

/**
 *
 * @author 09822000995
 */
public class Eleitor extends Cidadao implements java.io.Serializable{
    private String tituloDeEleitor;
    private Cidade cidade;
    private boolean jaVotou;

    public Eleitor(Integer codigo, String tituloDeEleitor, String nome, Cidade ciadade) {
        super(codigo, nome);
        this.tituloDeEleitor = tituloDeEleitor;
        this.cidade = cidade;
        this.jaVotou = false;
    }
    public Eleitor(Integer codigo, String tituloDeEleitor, String nome) {
        super(codigo, nome);
        this.tituloDeEleitor = tituloDeEleitor;
        this.cidade = Cidade.FLORIANOPOLIS;
        this.jaVotou = false;
    }

    public String getTituloDeEleitor() {
        return tituloDeEleitor;
    }

    public void setTituloDeEleitor(String tituloDeEleitor) {
        this.tituloDeEleitor = tituloDeEleitor;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public boolean isJaVotou() {
        return jaVotou;
    }

    public void setJaVotou(boolean jaVotou) {
        this.jaVotou = jaVotou;
    }

       
    public boolean jaVotou() {
        return this.jaVotou;
    }    
    public void computaVoto() {
        this.jaVotou = true;
    }    
}
