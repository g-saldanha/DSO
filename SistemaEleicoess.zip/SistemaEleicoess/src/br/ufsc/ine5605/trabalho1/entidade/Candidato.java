/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.entidade;

import br.ufsc.ine5605.trabalho1.Enum.Cargo;
import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.Enum.Partido;

/**
 *
 * @author Eduardo
 */
public class Candidato extends Cidadao implements java.io.Serializable{
    
    private final Cidade cidade;
    private final Cargo cargo;
    private Partido partido;
    
    private int votosRecebidos;
        
    public Candidato(Integer codigo, String nome, Partido partido, Cidade cidade, Cargo cargo) {
        super(codigo, nome);        
        this.partido = partido;
        this.cidade = cidade;
        this.cargo = cargo;
    }
    public Candidato(Integer codigo, String nome, Partido partido) {
        super(codigo, nome);        
        this.partido = partido;
        this.cidade = Cidade.FLORIANOPOLIS;
        this.cargo = Cargo.PREFEITO;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public Partido getPartido() {
        return partido;
    }
    
    public void setPartido(Partido partido){
        this.partido = partido;
    }
    
    public Partido getPartidoPeloNumero(int numero){
        return partido.getPartido(numero);
    }
    
    
    public void receberVoto(){
        this.votosRecebidos++;
    }
    
    public int getVotosRecebidos() {
        return votosRecebidos;
    }
}
