/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1;

import br.ufsc.ine5605.trabalho1.controle.ControladorPrincipal;

/**
 * controle apresentacao entidade
 * @author 09822000995
 */
public class SistemaEleicoes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        ControladorPrincipal controladorPrincipal = ControladorPrincipal.getIntance();        
        controladorPrincipal.inicia();    
        
    
    }
    
}
