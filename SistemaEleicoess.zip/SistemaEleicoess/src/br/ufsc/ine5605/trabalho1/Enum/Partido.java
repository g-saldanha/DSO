/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.Enum;

import java.util.logging.Logger;

/**
 *
 * @author Eduardo
 */
public enum Partido {
    PMDB(15),
    PP(11),
    PSOL(50),
    PSB(23),
    PSTU(33);
    
    private int numeroPartido;

    Partido(int numeroPartido){
        this.numeroPartido = numeroPartido;
    }

    public int getNumeroPartido() {
        return numeroPartido;
    }   
    
    public Partido getPartido(int numeroDoPartido){
        for(Partido partido : Partido.values()){
            if(numeroDoPartido == partido.numeroPartido)
                return partido;
        }
    return null;
    }
    
}
