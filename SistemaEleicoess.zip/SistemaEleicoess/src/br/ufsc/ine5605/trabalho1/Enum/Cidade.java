/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.Enum;

/**
 *
 * @author Eduardo
 */
public enum Cidade implements java.io.Serializable{
    FLORIANOPOLIS(1),
    SAOJOSE(2);
    
    private int codigo;
    
    Cidade(int codigo){
        this.codigo = codigo;
    }
    public int getCodigo(){
        return this.codigo;
    }
    public Cidade getCidade(int codigoDaCidade){
        for(Cidade cidade : Cidade.values()){
            if(codigoDaCidade == cidade.codigo)
                return cidade;
        }
    return null;
    }
    
}
