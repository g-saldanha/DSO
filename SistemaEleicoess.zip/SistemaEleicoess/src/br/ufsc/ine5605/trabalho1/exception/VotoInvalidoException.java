/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.exception;

/**
 *
 * @author Eduardo
 */
public class VotoInvalidoException extends Exception{
    public VotoInvalidoException(){
        super("Insira um numero enter 1 e 99");
    }
}
