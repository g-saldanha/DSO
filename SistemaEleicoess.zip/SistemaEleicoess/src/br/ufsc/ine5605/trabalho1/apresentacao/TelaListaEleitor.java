/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.controle.ControladorEleitor;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SpringLayout.Constraints;

/**
 *
 * @author Eduardo
 */
public class TelaListaEleitor extends JFrame{
    
    private String[] cabecalho;
    private JTable tabela;
    private Object tabelaEleitores[][];
    private JButton btVoltar;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    private GerenciadorDeBotoes gerenciadorBotoes;
    private ControladorEleitor owner; 
    private Container container;
    
    public TelaListaEleitor(ControladorEleitor owner){
        super("Eleitores cadastrados");
        this.owner = owner;
        
        container = getContentPane();
        
        iniciaComponentes();        
        
        btVoltar.addActionListener(gerenciadorBotoes);
        
        setSize(350, 150);
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
    }
    
    private Object[][] atualizarTabelaEleitores(){
        System.out.println(owner.getEleitores().size());
        tabelaEleitores = new Object[owner.getEleitores().size()][3];
        int i = 0;
        /*for(Cidadao eleitor : owner.getEleitores()){           
            Eleitor meuEleitor = (Eleitor) eleitor;
            this.tabelaEleitores[i][0] = meuEleitor.getCodigo();
            this.tabelaEleitores[i][1] = meuEleitor.getNome();
            this.tabelaEleitores[i][2] = meuEleitor.getTituloDeEleitor();
            i++;
        }*/
        return this.tabelaEleitores;
    }

    private class GerenciadorDeBotoes implements ActionListener{
        
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            if(e.getActionCommand().equals(btVoltar.getText())){
                setVisible(false);
                owner.exibeTelaEleitor();
            }                
        }        
    }
    
    private void iniciaComponentes(){
        
        Constraints constraints = new Constraints();        
        gerenciadorBotoes = new GerenciadorDeBotoes();
                 
        cabecalho = new String[] {"Codigo", "Nome", "Titulo"};
        
        tabela = new JTable(this.atualizarTabelaEleitores(), this.cabecalho);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane scroll = new JScrollPane(tabela);
        super.add(scroll, -1);
        
        //container.add(scroll, constraints);        
        
        btVoltar = new JButton();
        btVoltar.setText("Voltar");
        btVoltar.setActionCommand(btVoltar.getText());
        //container.add(btVoltar, constraints);       
        //super.add(btVoltar, -1);
        
    }
    
}
