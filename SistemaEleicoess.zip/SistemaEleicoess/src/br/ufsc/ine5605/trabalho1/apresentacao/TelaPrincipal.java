/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.OpcoesMenuPrincipal;
import br.ufsc.ine5605.trabalho1.controle.ControladorPrincipal;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author 09822000995
 */
public class TelaPrincipal extends JFrame{
    private final ControladorPrincipal owner;
    private Scanner sc;
    
    private JLabel lbTelaPrincipal;
    private JButton btMenuEleitor;
    private JButton btMenuCandidato;
    private JButton btMenuUrna;
    private JButton btIniciarVotacao;
    
    private GerenciadorDeBotoes gerenciadorBotoes;   
    private Container container;
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaPrincipal(ControladorPrincipal owner) {
        super("Tela Principal"); 
        this.owner = owner;      
        this.sc = new Scanner(System.in);
        
        container = getContentPane();
        container.setLayout(new GridBagLayout());
        
        this.iniciaComponentes();
        
        btMenuEleitor.addActionListener(gerenciadorBotoes);
        btMenuCandidato.addActionListener(gerenciadorBotoes);
        btMenuUrna.addActionListener(gerenciadorBotoes);
        btIniciarVotacao.addActionListener(gerenciadorBotoes);
        
        setSize(350, 150); 
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);        
    }
  

    private void iniciaComponentes() {
        GridBagConstraints constraints = new GridBagConstraints();        
        gerenciadorBotoes = new GerenciadorDeBotoes();
        
        btMenuEleitor = new JButton();
        btMenuEleitor.setText("Menu Eleitor");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        btMenuEleitor.setActionCommand(OpcoesMenuPrincipal.ELEITOR.name());
        container.add(btMenuEleitor, constraints);
        
        
        btMenuCandidato = new JButton();
        btMenuCandidato.setText("Menu Candidato");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 2;
        btMenuCandidato.setActionCommand(OpcoesMenuPrincipal.CANDIDATO.name());
        container.add(btMenuCandidato, constraints);
        
        btMenuUrna = new JButton();
        btMenuUrna.setText("Menu Urna");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 3;
        btMenuEleitor.setActionCommand(OpcoesMenuPrincipal.URNA.name());
        container.add(btMenuUrna, constraints);
        
        
        btIniciarVotacao = new JButton();
        btIniciarVotacao.setText("Iniciar votacao");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 4;
        btIniciarVotacao.setActionCommand(OpcoesMenuPrincipal.VOTACAO.name());
        container.add(btIniciarVotacao, constraints);
        
    }
    private class GerenciadorDeBotoes implements ActionListener {

         @Override
         public void actionPerformed(java.awt.event.ActionEvent e) {
                  
            if(e.getActionCommand().equals(OpcoesMenuPrincipal.ELEITOR.name())){
                owner.exibeTelaEleitor();
            }
            else if(e.getActionCommand().equals(OpcoesMenuPrincipal.CANDIDATO.name())){
                owner.exibeTelaCandidato();
   
            }
            else if(e.getActionCommand().equals(OpcoesMenuPrincipal.URNA.name())){
                owner.exibeTelaUrna();
            }
            else if(e.getActionCommand().equals(OpcoesMenuPrincipal.VOTACAO.name())){
                owner.iniciaVotacao();
            } 
        }   
    }
}
