/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.controle.ControladorVotacao;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author 09822000995
 */
public class TelaInserirTitulo extends JFrame{
    
    private ControladorVotacao owner;
    
    private JLabel lbTitulo;
    private JTextField tfTitulo;
    private JButton btVotar;
    
    private GerenciadorDeBotoes gerenciadorBotoes;    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaInserirTitulo(ControladorVotacao owner){
        this.owner = owner;
        this.iniciaComponentes();
        
        setSize(350, 150);     
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
        
    }


    private void iniciaComponentes() {
        
        this.setLayout( new FlowLayout());
        this.lbTitulo = new JLabel("Titulo de Eleitor: ");
        this.tfTitulo = new JTextField(15);
        this.btVotar = new JButton("Votar");
        
        add(lbTitulo);
        add(tfTitulo);
        add(btVotar);
        
        this.btVotar.addActionListener( new GerenciadorDeBotoes());        
        
    }

    private class GerenciadorDeBotoes implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            owner.validarTitulo();
        }
    }
}
