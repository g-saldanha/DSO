/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.controle.ControladorUrna;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SpringLayout;

/**
 *
 * @author Caio
 */
public class TelaListaUrna extends JFrame{
    
    private String[] cabecalho;
    private JTable tabela;
    private Object tabelaUrnas[][];
    private JButton btVoltar;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    private TelaListaUrna.GerenciadorDeBotoes gerenciadorBotoes;
    private ControladorUrna owner;
    private Container container;
    
    public TelaListaUrna(ControladorUrna owner){
        super("Urnas cadastrados");
        this.owner = owner;
        
        container = getContentPane();
        
        iniciaComponentes();        
        
        btVoltar.addActionListener(gerenciadorBotoes);
        
        setSize(350, 150);
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
    }

    private Object[][] atualizarTabelaUrnas(){
        System.out.println(owner.getUrnas().size());
        tabelaUrnas = new Object[owner.getUrnas().size()][3];
        int i = 0;
        /*for(Cidadao eleitor : owner.getEleitores()){           
            Eleitor meuEleitor = (Eleitor) eleitor;
            this.tabelaEleitores[i][0] = meuEleitor.getCodigo();
            this.tabelaEleitores[i][1] = meuEleitor.getNome();
            this.tabelaEleitores[i][2] = meuEleitor.getTituloDeEleitor();
            i++;
        }*/
        return this.tabelaUrnas;
    }    
    

    private class GerenciadorDeBotoes implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getActionCommand().equals(btVoltar.getText())){
                setVisible(false);
                owner.exibeTelaUrna();
            }
            
        }

        
    }
    
    private void iniciaComponentes(){
        
        SpringLayout.Constraints constraints = new SpringLayout.Constraints();        
        gerenciadorBotoes = new TelaListaUrna.GerenciadorDeBotoes();
                 
        cabecalho = new String[] {"Codigo"};
        
        tabela = new JTable(this.atualizarTabelaUrnas(), this.cabecalho);
        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        JScrollPane scroll = new JScrollPane(tabela);
        super.add(scroll, -1);
        
        //container.add(scroll, constraints);        
        
        btVoltar = new JButton();
        btVoltar.setText("Voltar");
        btVoltar.setActionCommand(btVoltar.getText());
        //container.add(btVoltar, constraints);       
        //super.add(btVoltar, -1);
        
    }    
    
    
    
}
