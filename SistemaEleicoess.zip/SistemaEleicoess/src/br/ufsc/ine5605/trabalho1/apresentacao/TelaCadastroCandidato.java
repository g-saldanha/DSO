/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.OpcoesCadastroCandidato;
import br.ufsc.ine5605.trabalho1.Enum.Partido;
import br.ufsc.ine5605.trabalho1.controle.ControladorCandidato;
import br.ufsc.ine5605.trabalho1.exception.AlteracaoIncorretaException;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Eduardo
 */
public class TelaCadastroCandidato extends JFrame {
    
    private JLabel lbCadastro;
    private JLabel lbCodigo;
    private JLabel lbNome;
    private JLabel lbNumeroPartido;
    private JButton btCadastro;
    private JButton btCancel;
    private JTextField tfNome;
    private JTextField tfCodigo;
    private JComboBox<Partido> bjPartidos;
    private JTextField tfNumeroPartido;    
    
    private GerenciadorDeBotoes gerenciadorBotoes;
    private ControladorCandidato owner;
    private Container container;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaCadastroCandidato(ControladorCandidato owner){
        
        super("Cadastro de candidato");     
        this.owner = owner;
        container = getContentPane();
        container.setLayout(new GridBagLayout());
        
        this.iniciaComponentes();
        
        btCadastro.addActionListener(gerenciadorBotoes);
        btCancel.addActionListener(gerenciadorBotoes);
        bjPartidos.addActionListener(gerenciadorBotoes);   
        
        setSize(350, 150);     
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
   
    }

   private void iniciaComponentes(){
        
        GridBagConstraints constraints = new GridBagConstraints();        
        gerenciadorBotoes = new GerenciadorDeBotoes();        
        
        lbCadastro = new JLabel();
        lbCadastro.setText("Cadastro de Candidato");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        container.add(lbCadastro, constraints);
        
        lbCodigo = new JLabel();
        lbCodigo.setText("Codigo");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 1;
        container.add(lbCodigo, constraints);
        
        tfCodigo = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        tfCodigo.setSize(100, 20);
        tfCodigo.setPreferredSize(new Dimension(100,20));
        container.add(tfCodigo, constraints);
        
        lbNome = new JLabel();
        lbNome.setText("Nome");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 2;
        lbNome.setSize(100, 20);
        lbNome.setPreferredSize(new Dimension(100,20));
        container.add(lbNome, constraints);
        
        tfNome = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 2;
        container.add(tfNome, constraints);
        
        lbNumeroPartido = new JLabel();
        lbNumeroPartido.setText("Partido");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 3;
        lbNumeroPartido.setSize(100, 20);
        lbNumeroPartido.setPreferredSize(new Dimension(100,20));
        container.add(lbNumeroPartido, constraints);
        
        bjPartidos = new JComboBox<Partido>(Partido.values());        
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 3;
        container.add(bjPartidos, constraints);        
             
        btCadastro = new JButton();
        btCadastro.setText("Cadastrar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 4;
        btCadastro.setActionCommand(OpcoesCadastroCandidato.CADASTRAR.name());
        container.add(btCadastro, constraints);
                
        btCancel = new JButton();
        btCancel.setText("Voltar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 4;
        btCancel.setActionCommand(OpcoesCadastroCandidato.CANCELAR.name());
        container.add(btCancel, constraints);
    }  

    private class GerenciadorDeBotoes implements ActionListener{
        
        @Override
        public void actionPerformed(ActionEvent e) {
            
            if(e.getActionCommand().equals(OpcoesCadastroCandidato.CADASTRAR.name())){
                Integer codigoCandidato = -1;
                              
                try {
                    codigoCandidato = Integer.valueOf(tfCodigo.getText());
                    owner.cadastraCandidato(codigoCandidato, tfNome.getText(), (Partido) bjPartidos.getSelectedItem());
                    JOptionPane.showMessageDialog(null, "Novo Candidato Cadastrado:\n"
                    + "\nNome: " + tfNome.getText()  
                    + "\nPartido: " + bjPartidos.getSelectedItem().toString()
                    + "\nCodigo: " + tfCodigo.getText() );
                } catch (AlteracaoIncorretaException ex) {
                    JOptionPane.showMessageDialog(null, "Algo de errado aconteceu" );
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Eleitor com codigo inválido!");
                } catch (CadastroIncorretoException ex) {  
                    Logger.getLogger(TelaCadastroCandidato.class.getName()).log(Level.SEVERE, null, ex);
                }
                tfCodigo.setText(null);
                tfNome.setText(null);
            }
            else if(e.getActionCommand().equals(OpcoesCadastroCandidato.CANCELAR.name())){
                setVisible(false);
                owner.exibeTelaCandidato();
            }             
        }  
    }
}
