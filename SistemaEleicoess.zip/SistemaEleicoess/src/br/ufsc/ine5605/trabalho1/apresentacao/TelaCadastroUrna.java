/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.OpcoesCadastroCandidato;
import br.ufsc.ine5605.trabalho1.controle.ControladorUrna;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Caio
 */
public class TelaCadastroUrna extends JFrame{
    private JLabel lbCadastro;
    private JLabel lbCodigo;
    private JButton btCadastro;
    private JButton btCancel;
    private JTextField tfCodigo;
    
    private GerenciadorDeBotoes gerenciadorBotoes;
    private ControladorUrna owner;
    private Container container;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaCadastroUrna(ControladorUrna owner) {
        super("Cadastro de Urna");
        
        this.owner = owner;
        container = getContentPane();
        container.setLayout(new GridBagLayout());
        
        this.iniciaComponentes();
        
        btCadastro.addActionListener(gerenciadorBotoes);
        btCancel.addActionListener(gerenciadorBotoes);
        
        setSize(350, 150);
        
        setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
    }

    private void iniciaComponentes() {
        
        GridBagConstraints constraints = new GridBagConstraints();        
        gerenciadorBotoes = new TelaCadastroUrna.GerenciadorDeBotoes();
        
        lbCadastro = new JLabel();
        lbCadastro.setText("Cadastro de Urna");
         constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        container.add(lbCadastro, constraints);
        
        lbCodigo = new JLabel();
        lbCodigo.setText("Codigo");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 1;
        container.add(lbCodigo, constraints);
        
        tfCodigo = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        tfCodigo.setSize(100, 20);
        tfCodigo.setPreferredSize(new Dimension(100,20));
        container.add(tfCodigo, constraints);
        
        btCadastro = new JButton();
        btCadastro.setText("Cadastrar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 4;
        btCadastro.setActionCommand(OpcoesCadastroCandidato.CADASTRAR.name());
        container.add(btCadastro, constraints);
        
        btCancel = new JButton();
        btCancel.setText("Cancelar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 4;
        btCancel.setActionCommand(OpcoesCadastroCandidato.CANCELAR.name());
        container.add(btCancel, constraints);
    }

    private class GerenciadorDeBotoes implements ActionListener {

        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            if(e.getActionCommand().equals(OpcoesCadastroCandidato.CADASTRAR.name())) {
                Integer codigoUrna = -1;
                
                try {
                    codigoUrna = Integer.valueOf(tfCodigo.getText());
                    owner.cadastraUrna(codigoUrna);
                    JOptionPane.showMessageDialog(null, "Eleitor cadastrado com sucesso" );
                } catch (CadastroIncorretoException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Urna com codigo inválido!");
                }
                tfCodigo.setText(null);

            }
            
            else if(e.getActionCommand().equals(OpcoesCadastroCandidato.CANCELAR.name())){
                setVisible(false);
                owner.exibeTelaUrna();
            }
                
        }

        
    }
    
    
}
