/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.controle.ControladorEleitor;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author 09822000995
 */
public class TelaEleitor extends JFrame{
    private ControladorEleitor owner;
    private Scanner sc;
    
    private EleitorTableModel modelo;
    private JPanel painelFundo;
    private JPanel painelBotoes;
    private JTable tabela;
    private JScrollPane barraRolagem;
    private JButton btInserir;
    private JButton btExcluir;
    private JButton btVoltar;

    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaEleitor(ControladorEleitor owner){
        super("Tela Eleitor"); 
        
        this.owner = owner;
        sc = new Scanner(System.in);        
        
        criaJTable();
        criaJanela();
        
        //container = getContentPane();
        //container.setLayout(new GridBagLayout());
        
        //this.iniciaComponentes();
        
        //btCadastrar.addActionListener(gerenciadorBotoes);
        //btAlterar.addActionListener(gerenciadorBotoes);
        //btExcluir.addActionListener(gerenciadorBotoes);
        //btListarEleitores.addActionListener(gerenciadorBotoes);
        
        setLocation(dim.width/2 - this.getSize().width/2, dim.height/2 - this.getSize().height/2);
    }
    
     public void criaJanela() {
         
        btInserir = new JButton("Inserir");
        btExcluir = new JButton("Excluir");
        btVoltar = new JButton("Voltar");
        
        painelBotoes = new JPanel();
        barraRolagem = new JScrollPane(tabela);
        painelFundo = new JPanel();
        painelFundo.setLayout(new BorderLayout());
        
        painelFundo.add(BorderLayout.CENTER, barraRolagem);
        painelBotoes.add(btInserir);
        painelBotoes.add(btVoltar);
        painelBotoes.add(btExcluir);
        painelFundo.add(BorderLayout.SOUTH, painelBotoes);

        getContentPane().add(painelFundo);
        setSize(500, 320);
        
        btInserir.addActionListener(new BtInserirListener());
        btVoltar.addActionListener(new btVoltarListener());
        btExcluir.addActionListener(new BtExcluirListener());
    }

    public void criaJTable() {
        modelo = new EleitorTableModel(this, owner.getEleitores());
        tabela = new JTable(modelo);
        tabela.setModel(modelo);
    }
    
    public void atualizaEleitor(Eleitor eleitor){
        owner.alteraEleitor(eleitor);
        modelo.atualizarDados(owner.getEleitores());
    }
    
    
    
    private class BtInserirListener implements ActionListener {
	
	public void actionPerformed(ActionEvent e) {   
            owner.exibeTelaCadastroEleitor();   
            setVisible(false);
            modelo.atualizarDados(owner.getEleitores());
            modelo.fireTableDataChanged();
        }
    }

    private class btVoltarListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
           owner.voltar();
        }
    }

    private class BtExcluirListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            int linhaSelecionada = -1;
            linhaSelecionada = tabela.getSelectedRow();
            if (linhaSelecionada >= 0) {   
                owner.excluiEleitor( (Eleitor) modelo.getEleitor(linhaSelecionada));
                modelo.atualizarDados(owner.getEleitores());
                modelo.fireTableRowsDeleted(linhaSelecionada, linhaSelecionada);
            } else {
                JOptionPane.showMessageDialog(null, "É necessário selecionar uma linha.");
            }            
        }
    }
}

