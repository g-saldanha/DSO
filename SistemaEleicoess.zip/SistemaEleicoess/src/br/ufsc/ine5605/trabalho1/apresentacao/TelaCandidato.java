/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.OpcoesMenuCidadao;
import br.ufsc.ine5605.trabalho1.Enum.Partido;
import br.ufsc.ine5605.trabalho1.controle.ControladorCandidato;
import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import java.awt.BorderLayout;
import java.util.Scanner;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;

/**
 *
 * @author Eduardo
 */
public class TelaCandidato extends JFrame{

    private ControladorCandidato owner;
    private Scanner sc;
        
    private CandidatoTableModel modelo;    
    private JPanel painelFundo;
    private JPanel painelBotoes;
    private JTable tabela;
    private JScrollPane barraRolagem;
    private JButton btCadastrar;
    private JButton btExcluir;
    private JButton btVoltar;    
     
    private GerenciadorDeBotoes gerenciadorBotoes;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

    public TelaCandidato(ControladorCandidato owner) {
        super("Menu Candidato"); 
        
        this.owner = owner;
        sc = new Scanner(System.in);
                        
        this.iniciaComponentes();        
        
        setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    }


    /*
    public void telaCadastroCandidato() {
    
    }

    public void telaAlteraCandidato() {
               
    }

    public void trataOpcaoAlteracao(int opcao) {        
       
    }

    public void telaRemoveCandidato() {
        
    }/*
    public void exibeInfoCandidato(Candidato candidato) {
       
    }
*/
    /*
    public void mensagemNaoHaCandidatos() {
        System.out.println("Nao ha candidatos cadastrados\n");
    }
    public Cidadao telaEscolheCandidato(){
        System.out.println("Insira o codigo ou partido do candidato a ser removido");
        owner.exibeCandidatosCadastrados();
        Integer codigo = -1;
        try{
            codigo = (Integer) sc.nextInt();
        } catch (InputMismatchException ex){
             System.out.println("Informacao de imput incorreta");
        }   
         try {            
            return owner.buscaCandidato(codigo);
        } catch (AlteracaoIncorretaException ex) {
            System.out.println("Codigo inexistente");
            return null;
        }
    }
    /*/

    public void iniciaComponentes() {        
        criaJTable();
        criaJanela();           
    }
    public void setupPartidos(JTable tabela, TableColumn colunaPartido){
        JComboBox<Partido> cbPartidos = new JComboBox<>(Partido.values());      
        colunaPartido.setCellEditor(new DefaultCellEditor(cbPartidos));
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setToolTipText("Click for combo box");
        colunaPartido.setCellRenderer(renderer);
    }  

    void atualizaCandidato(Candidato candidato) {
        owner.alteraCandidato(candidato);
        modelo.atualizarDados(owner.getCandidatos());
    }

    public void criaJTable() {
        modelo = new CandidatoTableModel(this, owner.getCandidatos());
        tabela = new JTable(modelo);
        tabela.setModel(modelo);
        setupPartidos(tabela,tabela.getColumnModel().getColumn(2));
    }

    private void criaJanela() {        
        gerenciadorBotoes = new GerenciadorDeBotoes();
        
        btCadastrar = new JButton("Cadastrar");           
        btVoltar = new JButton("Voltar");               
        btExcluir = new JButton("Excluir Candidato");
        
        btCadastrar.setActionCommand(OpcoesMenuCidadao.CADASTRAR.toString());
        btVoltar.setActionCommand(OpcoesMenuCidadao.VOLTAR.toString());
        btExcluir.setActionCommand(OpcoesMenuCidadao.EXCLUIR.toString());
        
        painelBotoes = new JPanel();
        barraRolagem = new JScrollPane(tabela);
        painelFundo = new JPanel();
        painelFundo.setLayout(new BorderLayout());
        
        painelFundo.add(BorderLayout.CENTER, barraRolagem);
        painelBotoes.add(btCadastrar);
        painelBotoes.add(btVoltar);
        painelBotoes.add(btExcluir);
        painelFundo.add(BorderLayout.SOUTH, painelBotoes);

        getContentPane().add(painelFundo);
        setSize(500, 320);
        
        btCadastrar.addActionListener(gerenciadorBotoes);
        btVoltar.addActionListener(gerenciadorBotoes);
        btExcluir.addActionListener(gerenciadorBotoes);
    }

    private class GerenciadorDeBotoes implements ActionListener {

         @Override
         public void actionPerformed(java.awt.event.ActionEvent e) {
                  
            if(e.getActionCommand().equals(OpcoesMenuCidadao.EXCLUIR.name())){
                int linhaSelecionada = tabela.getSelectedRow();  
                owner.excluiCandidato((Candidato) modelo.getCandidato(linhaSelecionada));
                modelo.atualizarDados(owner.getCandidatos());
                modelo.fireTableRowsDeleted(linhaSelecionada, linhaSelecionada);
            }
            else if(e.getActionCommand().equals(OpcoesMenuCidadao.VOLTAR.name())){
                owner.voltar();
            }            
            else if(e.getActionCommand().equals(OpcoesMenuCidadao.CADASTRAR.name())){
                owner.exibeTelaCadastroCandidato();
                setVisible(false);
            }     
        }   
    }
}