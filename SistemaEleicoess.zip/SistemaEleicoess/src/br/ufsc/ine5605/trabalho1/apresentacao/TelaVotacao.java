/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.Cidade;
import br.ufsc.ine5605.trabalho1.Enum.Cargo;
import br.ufsc.ine5605.trabalho1.controle.ControladorVotacao;
import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import br.ufsc.ine5605.trabalho1.entidade.SecaoEleitoral;
import br.ufsc.ine5605.trabalho1.entidade.ZonaEleitoral;
import br.ufsc.ine5605.trabalho1.exception.TituloInvalidoException;
import br.ufsc.ine5605.trabalho1.exception.VotoInvalidoException;
import br.ufsc.ine5605.trabalho1.exception.naoHaVencedorException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author 09822000995
 */
public class TelaVotacao {
    
    private Scanner sc;
    private ControladorVotacao owner;
    
    private JLabel lbTitulo;
    private JTextField tfTitulo;
    private JButton btVotar;

    private GerenciadorDeBotoes gerenciadorBotoes;
    
    public TelaVotacao(ControladorVotacao owner) {
        this.owner = owner;
        sc = new Scanner(System.in);
    }
    
    public void exibeTelaVotacao(){
        int opcao = 0;
        do{
            System.out.println("");
            System.out.println("Bem vindo a votacao");
            System.out.println("Para votar, digite 1");
            System.out.println("Para contabilizar a eleicao, digite 2");       
            System.out.println("Para informar vencedores, digite 3");       
            System.out.println("Para retornar, digite 0");  
            opcao = sc.nextInt();
            trataOpcao(opcao);
        }while(opcao != 0);
    }
    public void trataOpcao(int opcao){
        switch(opcao){
            case 1:
                this.telaEscolheZonaEleitoral();
                break;
            case 2:    
                this.telaContabilizaEleicao();
                break;
            case 3:        
                owner.calcularTotais();
                break;
            default:
                System.out.println("Opcao inexistente");
        }        
    }
    public void telaEscolheZonaEleitoral(){
        System.out.println("Escolha a zona eleitoral pelo numero");
        owner.exibeZonasEleitoraisCadastradas();
        int zona = sc.nextInt();
        ZonaEleitoral zonaEscolhida = owner.selecionaZonaEleitoral(zona);
        if(zonaEscolhida == null){
            System.out.println("Zona inexistente");
            return;
        }
        this.telaEscolheSecao(zonaEscolhida);
    }
    public void telaMostraVencedore(Candidato vencedor){     
        System.out.println("Vencedor de " + vencedor.getCidade() + " para o cargo de "+ vencedor.getCargo() + " foi " + vencedor.getNome() +" do " + vencedor.getPartido());
    }
        
    public void telaContabilizaEleicao(){
        System.out.print("Digite " + Cidade.FLORIANOPOLIS.getCodigo());
        System.out.println(" para contabilizar " + Cidade.FLORIANOPOLIS);
        System.out.print("Digite " + Cidade.SAOJOSE.getCodigo());
        System.out.println(" para contabilizar " + Cidade.SAOJOSE);
        int codigoCidade = sc.nextInt();        
        this.telaContabilizaPorCargo(codigoCidade);        
    }
    
    public void telaContabilizaPorCargo(int codigoCidade){
        System.out.println("Digite o codigo do cargo: ");
        System.out.println(Cargo.PREFEITO.getCodigo() + " para " + Cargo.PREFEITO);
        System.out.println(Cargo.VEREADOR.getCodigo() + " para " + Cargo.VEREADOR);
        int codigoCargo = sc.nextInt();        
        owner.contabilizarVotosEleicao(codigoCidade, codigoCargo);         
    }

    public void exibeInfoZonaEleitoral(ZonaEleitoral zona) {
        System.out.println("Zona " + zona.getCodigo() + " de " + zona.getCidade());
    }

    public void exibeInfoEleitor(Cidadao eleitor) {
        Eleitor infoEleitor = (Eleitor) eleitor;
        System.out.println("Nome do eleitor: " + eleitor.getNome() + " titulo " + infoEleitor.getTituloDeEleitor());
    }
    public void exibeVoto(Candidato candidato, int voto){
        System.out.println("Candidato " + candidato.getNome() + " recebeu " + voto);
    }    
    
    public void telaEscolheSecao(ZonaEleitoral zona){
        System.out.println("Escolha a secao eleitoral pelo numero");        
        owner.exibeSecoesEleitoraisCadastradas(zona);
        SecaoEleitoral secao = owner.selecionaSecaoEleitoral(zona ,sc.nextInt());
        if(secao == null){
            System.out.println("Secao inexistente");
            return;
        }
        System.out.println("Eleitores cadastrados nessa secao:");
        owner.exibeEleitoresCadastradosNaUrna(secao);
        this.telaHoraDeVotar(secao);
    }

    public void exibeInfoSecaoEleitoral(SecaoEleitoral secao) {
        System.out.println("Secao: " + secao.getCodigo());
    }

    public void telaHoraDeVotar(SecaoEleitoral secao) {
        /*
        System.out.println("Insira seu titulo de eleitor:");
        int tituloDeEleitor = sc.nextInt();
        Eleitor eleitor = null;
        try {
            eleitor = owner.verificarTituloDeEleitor(tituloDeEleitor, secao);
        } catch (TituloInvalidoException ex) {
            System.out.println("Erro: " + ex.getMessage());
            System.out.println("Retornando ao menu de votacao...");
            return;
        }
        */
        System.out.println("Eleitor qualificado para votar.");   
        //this.telaEscolheCandidatoPrefeito(secao, eleitor);
    }
    public void telaEscolheCandidatoPrefeito(SecaoEleitoral secao, Eleitor eleitor) {
        System.out.println("Insira o partido do candidato a prefeito:");
        int candidatoPrefeito = sc.nextInt();
        try {               
            owner.trataVoto(secao, candidatoPrefeito, eleitor, 1);
        } catch (VotoInvalidoException ex) {
           System.out.println("Erro ao votar: " + ex.getMessage());           
        }        
        this.telaEscolheCandidatoVereador(secao, eleitor);
    }    
    private void telaEscolheCandidatoVereador(SecaoEleitoral secao, Eleitor eleitor) {
        System.out.println("Insira o partido do candidato a vereador:");
        int candidatoVereador = sc.nextInt();
        try {               
            owner.trataVoto(secao, candidatoVereador, eleitor, 1);
        } catch (VotoInvalidoException ex) {
           System.out.println("Erro ao votar: " + ex.getMessage());           
        }  
    }
    
    public void telaMostraCandidatoVotado(Candidato candidato){
        if(candidato == null){
            System.out.println("Voto anulado!");
            return;
        }        
        System.out.println("Candidato votado:");
        System.out.println(candidato.getNome() + " do partido "+ candidato.getPartido() + " para o cargo de " + candidato.getCargo());            
    }
    public void mensagemVotoBranco(){
        System.out.println("Voto em branco");
    }

    

    public void mensagemNaoHaVencedor(Cidade cidade) {
        System.out.println("Nao ha vencedor em " + cidade);
    }

    public void exibeVotosBrancosENulos(int brancos, int nulos) {
        System.out.println("Brancos: " + brancos);
        System.out.println("Nulos: " + nulos);        
    }

    private static class GerenciadorDeBotoes {

        public GerenciadorDeBotoes() {
        }
    }
}
