/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Eduardo
 */
public class EleitorTableModel extends AbstractTableModel{

    private static final int CODIGO = 0;
    private static final int NOME = 1;
    private static final int TITULO = 2;
    private TelaEleitor owner;
    
    private String[] cabecalho = new String[] {"Codigo", "Nome", "Titulo"};
    private ArrayList<Cidadao> eleitores;
    
    public EleitorTableModel( TelaEleitor owner, HashMap<Integer, Cidadao> novosEleitores){
        this.owner = owner;
        this.eleitores = new ArrayList<>();
        this.atualizarDados(novosEleitores);
    }
    
    public void atualizarDados( HashMap<Integer, Cidadao> novosEleitores){
        eleitores.removeAll(eleitores);
        Cidadao eleitor;
        int i = 0;
        for(Integer keyEleitor : novosEleitores.keySet()){ // Percorrre as chaves do HashMap
            eleitor = novosEleitores.get(keyEleitor);      // Seleciona o eleitor correspondente 
            if(!eleitores.contains(eleitor)){              // Se o eleitor nao existe  
               eleitores.add(i, eleitor);                  // Novo eleitor 
            }
            i++;                                           // Nova posicao 
        }        
    }    
        

    public void setCabecalho(String[] cabecalho) {
        this.cabecalho = cabecalho;
    }
    
    @Override
    public int getRowCount() {
        return this.eleitores.size();
    }

    @Override
    public int getColumnCount() {
        return this.cabecalho.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return cabecalho[columnIndex];
    }  
    
    @Override
     public boolean isCellEditable(int row, int col){ 
         return true; 
     }
     
    public void setValueAt(Object value, int linha, int coluna) {
        Eleitor eleitor = (Eleitor) eleitores.get(linha); 
               
        switch(coluna){
           case NOME:
               eleitor.setNome((String)value);                
               break;
           case TITULO:
               eleitor.setTituloDeEleitor((String)value);
               break;
        }        
        owner.atualizaEleitor(eleitor);
        fireTableCellUpdated(linha, coluna);
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        
        Eleitor eleitor = (Eleitor) eleitores.get(linha); 
        if(eleitor == null)
            return null;
        
        switch(coluna){
            case CODIGO:
                return eleitor.getCodigo();
            case NOME:
                return eleitor.getNome();
            case TITULO:
                return eleitor.getTituloDeEleitor();
        }
        return null;
    }
    
    public Cidadao getEleitor(int indiceLinha) {
        return eleitores.get(indiceLinha);        
    }    
   
}
