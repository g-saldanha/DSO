/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.Partido;
import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.entidade.Eleitor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Eduardo
 */
public class CandidatoTableModel extends AbstractTableModel{

    private static final int CODIGO = 0;
    private static final int NOME = 1;
    private static final int PARTIDO = 2;
    private TelaCandidato owner;
    
    private String[] cabecalho = new String[] {"Codigo", "Nome", "Partido"};
    private ArrayList<Cidadao> candidatos;
    
    public CandidatoTableModel( TelaCandidato owner, HashMap<Integer, Cidadao> novosCandidatos){
        this.owner = owner;
        this.candidatos = new ArrayList<>();
        this.atualizarDados(novosCandidatos);
    }
    
    public void atualizarDados( HashMap<Integer, Cidadao> novosCandidatos){
        candidatos.removeAll(candidatos);
        Cidadao candidato;
        int i = 0;
        for(Integer keyEleitor : novosCandidatos.keySet()){ // Percorrre as chaves do HashMap
            candidato = novosCandidatos.get(keyEleitor);      // Seleciona o eleitor correspondente 
            if(!candidatos.contains(candidato)){              // Se o eleitor nao existe  
               candidatos.add(i, candidato);                  // Novo eleitor 
            }
            i++;                                           // Nova posicao 
        }        
    }    
        

    public void setCabecalho(String[] cabecalho) {
        this.cabecalho = cabecalho;
    }
    
    @Override
    public int getRowCount() {
        return this.candidatos.size();
    }

    @Override
    public int getColumnCount() {
        return this.cabecalho.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return cabecalho[columnIndex];
    }  
    
    @Override
     public boolean isCellEditable(int row, int col){ 
         return true; 
     }
     
    public void setValueAt(Object value, int linha, int coluna) {
        Candidato candidato = (Candidato) candidatos.get(linha); 
               
        switch(coluna){
           case NOME:
               candidato.setNome((String)value);                
               break;
           case PARTIDO:
               candidato.setPartido((Partido)value);
               break;
        }        
        owner.atualizaCandidato(candidato);
        fireTableCellUpdated(linha, coluna);
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
        
        Candidato candidato = (Candidato) candidatos.get(linha); 
        if(candidato == null)
            return null;
        
        switch(coluna){
            case CODIGO:
                return candidato.getCodigo();
            case NOME:
                return candidato.getNome();
            case PARTIDO:
                 return candidato.getPartido();
        }
        return null;
    }
    
    public Cidadao getCandidato(int indiceLinha) {
        return candidatos.get(indiceLinha);        
    }    
   
}
