/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.entidade.Urna;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Caio
 */
public class UrnaTableModel extends AbstractTableModel {
    
    private static final int CODIGO = 0;
    private static final int SECAO = 1;    
    private TelaUrna owner;
    
    private String[] cabecalho = new String[] {"Codigo", "Secao"};
    private ArrayList<Urna> urnas;
    
    public UrnaTableModel(TelaUrna owner, HashMap<Integer, Urna> novasUrnas) {
        this.owner = owner;
        this.urnas = new ArrayList<>();
        this.atualizarDados(novasUrnas);
    }

    @Override
    public int getRowCount() {
        return this.urnas.size();   
    }

    @Override
    public int getColumnCount() {
        return this.cabecalho.length;
    }

    public Object getColumnName(int rowIndex, int columnIndex) {
        return cabecalho[columnIndex];
    }
    
    @Override
     public boolean isCellEditable(int row, int col){ 
         return true; 
     }
     
     public void setValueAt(Object value, int linha, int coluna) {
        Urna urna = (Urna) urnas.get(linha); 
               
        switch(coluna){
           case CODIGO:
               urna.setCodigo((Integer)value);                
               break;
        }        
        owner.atualizaUrna(urna);
        fireTableCellUpdated(linha, coluna);
    }

    void atualizarDados(HashMap<Integer, Urna> novasUrnas) {
        urnas.removeAll(urnas);
        Urna urna;
        int i = 0;
        for(Integer keyUrna : novasUrnas.keySet()) {    // Percorrre as chaves do HashMap 
            urna = novasUrnas.get(keyUrna);             // Seleciona a urna correspondente
            if(!urnas.contains(urna)) {                 // Se a urna nao existe
                urnas.add(i, urna);                     // Nova urna 
            }
            i++;                                        // Nova posicao
        }
    }
    
    public void setCabecalho(String[] cabecalho) {
        this.cabecalho = cabecalho;
    }

    @Override
    public Object getValueAt(int linha, int coluna) {
            
        Urna urna = (Urna) urnas.get(linha); 
        if(urna == null)
            return null;
        
        switch(coluna){
            case CODIGO:
                return urna.getCodigo();
            
            
        }
        return null;
    }
        
    public Urna getUrna(int indiceLinha) {
        return urnas.get(indiceLinha);        
    } 
    
    
    
}
