/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.apresentacao;

import br.ufsc.ine5605.trabalho1.Enum.OpcoesCadastroCandidato;
import br.ufsc.ine5605.trabalho1.controle.ControladorEleitor;
import br.ufsc.ine5605.trabalho1.exception.CadastroIncorretoException;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

/**
 *
 * @author Eduardo
 */
public class TelaCadastroEleitor extends JFrame{
    private JLabel lbCadastro;
    private JLabel lbCodigo;
    private JLabel lbNome;
    private JLabel lbTituloDeEleitor;
    private JButton btCadastro;
    private JButton btCancel;
    private JTextField tfNome;
    private JTextField tfCodigo;
    private JTextField tfTituloDeEleitor;
    
    private GerenciadorDeBotoes gerenciadorBotoes;
    private ControladorEleitor owner;
    private Container container;
    
    private Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
    
    public TelaCadastroEleitor(ControladorEleitor owner){
        super("Cadastro de Eleitor");
        
        this.owner = owner;
        container = getContentPane();
        container.setLayout(new GridBagLayout());
        
        this.iniciaComponentes();
        
        btCadastro.addActionListener(gerenciadorBotoes);
        btCancel.addActionListener(gerenciadorBotoes);
    
        setSize(350, 150);  
        
        setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    
    }
    private void iniciaComponentes(){
        
        GridBagConstraints constraints = new GridBagConstraints();        
        gerenciadorBotoes = new GerenciadorDeBotoes();
        
        lbCadastro = new JLabel();
        lbCadastro.setText("Cadastro de Eleitor");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 0;
        container.add(lbCadastro, constraints);
        
        lbCodigo = new JLabel();
        lbCodigo.setText("Codigo");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 1;
        container.add(lbCodigo, constraints);
        
        tfCodigo = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 1;
        tfCodigo.setSize(100, 20);
        tfCodigo.setPreferredSize(new Dimension(100,20));
        container.add(tfCodigo, constraints);
        
        lbNome = new JLabel();
        lbNome.setText("Nome");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 2;
        lbNome.setSize(100, 20);
        lbNome.setPreferredSize(new Dimension(100,20));
        container.add(lbNome, constraints);
        
        tfNome = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 2;
        container.add(tfNome, constraints);
        
        lbTituloDeEleitor = new JLabel();
        lbTituloDeEleitor.setText("Titulo de Eleitor");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 3;
        lbTituloDeEleitor.setSize(100, 20);
        lbTituloDeEleitor.setPreferredSize(new Dimension(100,20));
        container.add(lbTituloDeEleitor, constraints);
        
        tfTituloDeEleitor = new JTextField();      
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 3;
        container.add(tfTituloDeEleitor, constraints);
        
        btCadastro = new JButton();
        btCadastro.setText("Cadastrar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 1;
        constraints.gridy = 4;
        btCadastro.setActionCommand(OpcoesCadastroCandidato.CADASTRAR.name());
        container.add(btCadastro, constraints);
                
        btCancel = new JButton();
        btCancel.setText("Cancelar");
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.gridx = 0;
        constraints.gridy = 4;
        btCancel.setActionCommand(OpcoesCadastroCandidato.CANCELAR.name());
        container.add(btCancel, constraints);
    }  

    private class GerenciadorDeBotoes implements ActionListener{
        
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) {
            
            if(e.getActionCommand().equals(OpcoesCadastroCandidato.CADASTRAR.name())){
                Integer codigoEleitor = -1;
                              
                try {
                    codigoEleitor = Integer.valueOf(tfCodigo.getText());
                    owner.cadastraEleitor(codigoEleitor, tfTituloDeEleitor.getText(), tfNome.getText());
                    JOptionPane.showMessageDialog(null, "Eleitor cadastrado com sucesso" );
                } catch (CadastroIncorretoException ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                } catch(NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Eleitor com codigo inválido!");
                }                
                tfCodigo.setText(null);
                tfNome.setText(null);
                tfTituloDeEleitor.setText(null);
            }
            else if(e.getActionCommand().equals(OpcoesCadastroCandidato.CANCELAR.name())){
                setVisible(false);
                owner.exibeTelaEleitor();
            }            
            
        }        
    }
}