/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.ufsc.ine5605.trabalho1.interfaces;

import br.ufsc.ine5605.trabalho1.entidade.Candidato;
import br.ufsc.ine5605.trabalho1.entidade.Cidadao;
import br.ufsc.ine5605.trabalho1.exception.AlteracaoIncorretaException;
import java.util.ArrayList;

/**
 *
 * @author Eduardo
 */
public interface IControladorCidadao {

    /**
     * Cadastra novo cidadao
     * @param codigo
     * @param nome
     */
    public void cadastraCidadao(int codigo, String nome);
    public <T> void alteraCidadao(Cidadao cidadao, T alteracao) throws AlteracaoIncorretaException;
    public void excluiCidadao(Cidadao cidadao, ArrayList<Cidadao> listaCidadaos);
    public void exibeCidadaosCadastrados();
    public void exibeTelaCidadao();
    public <T> Cidadao buscaCidadao(T informacao, ArrayList<Cidadao> listaCidadaos) throws AlteracaoIncorretaException;
}
