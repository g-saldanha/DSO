package exercicio4;

/*
 * Universidade Federal de Santa Catarina.
 * CTC - Centro Tecnologico - http://ctc.ufsc.br
 * INE - Departamento de Informatica e Estatistica - http://inf.ufsc.br
 */

import java.util.ArrayList;

/**
 *
 * @author Jean Hauck <jean.hauck at ufsc.br>
 * @date 15/04/2016
 */
public class Jogador implements IJogador {
    
    private String nome;
    private ArrayList<Carta> mao;

    public Jogador(String nome) {
        this.nome = nome;
        this.mao = new ArrayList<>();
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public ArrayList<Carta> getMao() {
        return mao;
    }
    
 
    @Override
    public Carta baixaCartaDaMao() {
        Carta carta = mao.get(0);
        removeCartaNaMao(carta);
        return carta;
    } 

    @Override
    public void incluiCartaNaMao(Carta carta) {
        if(carta != null)
            this.mao.add(carta);
    }

    @Override
    public void removeCartaNaMao(Carta carta) {
        if(carta != null)
            this.mao.remove(carta);
    }
}