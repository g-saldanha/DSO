package exercicio4;


import java.lang.reflect.Method;
import java.util.ArrayList;

/*
 * Universidade Federal de Santa Catarina.
 * CTC - Centro Tecnologico - http://ctc.ufsc.br
 * INE - Departamento de Informatica e Estatistica - http://inf.ufsc.br
 */

/**
 *
 * @author Jean Hauck <jean.hauck at ufsc.br>
 * @date 15/04/2016
 */
public class Carta implements ICarta {
    
    private Personagem personagem;

    public Carta(Personagem personagem) {
        this.personagem = personagem;
    }   

    @Override
    public int getValorTotalCarta() {
        int soma = 0;
        soma += this.personagem.getEnergia();
        soma += this.personagem.getHabilidade();
        soma += this.personagem.getVelocidade();
        soma += this.personagem.getResistencia();
        return soma;
    }

    @Override
    public void setPersonagem(Personagem personagem) {
        this.personagem = personagem;
    }

    @Override
    public Personagem getPersonagem() {
        return this.personagem;
    }
    
 
}