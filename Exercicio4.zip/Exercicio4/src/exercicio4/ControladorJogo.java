package exercicio4;

/*
 * Universidade Federal de Santa Catarina.
 * CTC - Centro Tecnologico - http://ctc.ufsc.br
 * INE - Departamento de Informatica e Estatistica - http://inf.ufsc.br
 */

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Jean Hauck <jean.hauck at ufsc.br>
 * @date 15/04/2016
 */
public class ControladorJogo implements IControladorJogo {
    
     private ArrayList<Personagem> listaPersonagem;
     private ArrayList<Carta> baralho;
     private ArrayList<Jogador> listaJogadores;
     private Jogador jogadorVencedor = null;

    public ControladorJogo() {
        this.listaPersonagem = new ArrayList<>();
        this.baralho = new ArrayList<>();
        this.listaJogadores = new ArrayList<>();
    }

    @Override
    public Personagem incluiPersonagemNaLista(int energia, int habilidade, int velocidade, int resistencia, TipoPersonagem tipo) {
        Personagem novoPersonagem = new Personagem(energia, habilidade, velocidade, resistencia, tipo);
        listaPersonagem.add(novoPersonagem);
        return novoPersonagem;
    }

    @Override
    public Carta incluiCartaNoBaralho(Personagem personagem) {
        Carta novaCarta = new Carta(personagem);
        baralho.add(novaCarta);
        return novaCarta;
    }

    @Override
    public Jogador incluiJogador(String nome) {
        Jogador novoJogador = new Jogador(nome);
        listaJogadores.add(novoJogador);
        return novoJogador;
    }

    @Override
    public void iniciaJogo(Jogador jogador1, Jogador jogador2) {
        Collections.shuffle(baralho);
        for(int i = 0; i < 10; i += 2){
            jogador1.incluiCartaNaMao(baralho.get(i));
            jogador2.incluiCartaNaMao(baralho.get(i + 1));
        }
        
    }

    @Override
    public Jogador jogada(Mesa mesa) {
        
        if(mesa.getJogador2().getMao().isEmpty() == true){
            this.jogadorVencedor = mesa.getJogador1(); 
            return jogadorVencedor;
        }
        if(mesa.getJogador1().getMao().isEmpty() == true){
            this.jogadorVencedor = mesa.getJogador2(); 
            return jogadorVencedor;
        }
        
        int valorCarta1 = mesa.getCartaJogador1().getValorTotalCarta();
        int valorCarta2 = mesa.getCartaJogador2().getValorTotalCarta();
        
        if(valorCarta1 > valorCarta2){
            mesa.getJogador1().incluiCartaNaMao(mesa.getCartaJogador2());
        }
        else{
            mesa.getJogador2().incluiCartaNaMao(mesa.getCartaJogador1());
        }
        
        return null;
    }
}