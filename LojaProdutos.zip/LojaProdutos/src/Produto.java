/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class Produto implements IProduto {
    
    private CategoriaProduto categoria;
    private int codigo;
    private String descricao;
    private String nome;
    private float preco;
    private int quantidade;

    Produto(int codigo, String nome, String descricao, float preco, int quantidade, CategoriaProduto categoria) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.quantidade = quantidade;
        this.categoria = categoria;
    }
    

    @Override
    public CategoriaProduto getCategoria() {
        return this.categoria;
    }

    @Override
    public int getCodigo() {
        return this.codigo;
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    @Override
    public String getNome() {
        return this.nome;
    }

    @Override
    public float getPreco() {
        return this.preco;
    }

    @Override
    public int getQuantidade() {
        return this.quantidade;
    }

    @Override
    public void setCategoria(CategoriaProduto categoria) {
        this.categoria = categoria;
    }

    @Override
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public void setPreco(float preco) {
        this.preco = preco;
    }

    @Override
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
    
}
