
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class ControladorProdutos implements IControladorProdutos {
    
    private ArrayList<Produto> produtos;
    
    
    public ControladorProdutos() {
        this.produtos = new ArrayList<>();
    }

    @Override
    public void atualizaPrecos(float inflacao) {
       for (Produto produto : produtos) {
                float valorCorrigido = ((inflacao / 100) * produto.getPreco()) + produto.getPreco();
                produto.setPreco(valorCorrigido);
       } 
    }

    @Override
    public IProduto getProdutoPeloCodigo(int codigo) {
        Produto produtoRetorna = null;
        for (Produto produto : produtos) {
                if (produto.getCodigo() == codigo) {
                    produtoRetorna = produto;
                }
        }
        return produtoRetorna;
    }

    @Override
    public ICategoriaProduto incluiCategoriaProduto(int codigo, String nome) {
        Produto produto = (Produto) this.getProdutoPeloCodigo(codigo);
        return null;       
    }

    @Override
    public IProduto incluiProduto(int codigo, String nome, String descricao, float preco, int quantidade, CategoriaProduto categoria) {
        Produto produto = new Produto(codigo, nome, descricao, preco, quantidade, categoria);
        produtos.add(produto);
        return produto;
    }
    
}
