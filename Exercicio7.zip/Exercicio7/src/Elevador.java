/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Caio
 */
public class Elevador implements IElevador{

    private int capacidade;
    private int totalPessoas;
    private int totalAndaresPredio;
    private int andarAtual;
    
    public Elevador(int andarAtual, int totalAndaresPredio, int capacidade, int totalPessoas) {
        this.capacidade = capacidade;
        this.totalPessoas = totalPessoas;
        this.totalAndaresPredio = totalAndaresPredio;
        this.andarAtual = andarAtual;
    }
    
    public String descer() {
        this.andarAtual -= 1;
        return "elevador Desceu 1 andar";
    }
    
    public String subir() {
        this.andarAtual += 1;
        return "elevador subiu 1 andar";
    }
    
    public String entraPessoa() {
        this.totalPessoas += 1;
        return "1 pessoa entrou no elevador";
    }
    
    public String saiPessoa() {
        this.totalPessoas -= 1;
        return "1 pessoa saiu do elevador";
    }
    
    
    
    public int getCapacidade() {
        return this.capacidade;
    }
    
    public int getTotalPessoas() {
        return this.totalPessoas;
    }
    
    public int getTotalAndaresPredio() {
        return this.totalAndaresPredio;
    }
    
    public int getAndarAtual() {
        return this.andarAtual;
    }
    
    public void setTotalAndaresPredio(int totalAndaresPredio) {
        this.totalAndaresPredio = totalAndaresPredio;
    }
}
