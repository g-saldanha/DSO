/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Caio
 */
public class ControladorElevador implements IControladorElevador {
    
    private Elevador elevador;
    


    @Override
    public String subir() {
        if(elevador.getAndarAtual() < elevador.getTotalAndaresPredio()) {
            return elevador.subir();
        } else {
            return "nao foi possivel subir";
        }
    }

    @Override
    public String descer() {
      if(elevador.getAndarAtual() > 0) {
          return elevador.descer();
      }  else {
          return "não foi possivel descer";
      }
    }

    @Override
    public String entraPessoa() {
        if(elevador.getTotalPessoas() < elevador.getCapacidade()) {
            return elevador.entraPessoa();
        } else {
            return "elevador cheio";
        }
    }
    

    @Override
    public String saiPessoa() {
        if(elevador.getTotalPessoas() > 0) {
            return elevador.saiPessoa();
        } else {
            return "nao ha pessoas";
        }
    }

    @Override
    public Elevador getElevador() {
        return this.elevador;
    }

    @Override
    public IElevador inicializarElevador(int andarAtual, int totalAndaresPredio, int capacidade, int totalPessoas) {
        Elevador elevador = new Elevador(andarAtual, totalAndaresPredio, capacidade, totalPessoas);
        this.elevador = elevador;
        return elevador;
    }
    
}
