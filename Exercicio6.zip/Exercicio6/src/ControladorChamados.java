
import java.util.ArrayList;
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class ControladorChamados implements IControladorChamados {
    
    private ArrayList<Chamado> chamados;
    private ArrayList<TipoChamado> tipoChamados;
    
    
    public ControladorChamados() {
        this.chamados = new ArrayList<>();
        this.tipoChamados = new ArrayList<>();
    }

    @Override
    public int getTotalChamadosPorTipo(TipoChamado tipo) {
        int contador = 0;
        for (Chamado chamado : chamados) {
            if(chamado.getTipo() == tipo) {
            contador++;
            }     
        }
        
        return contador;
        }


    @Override
    public IChamado incluiChamado(Date data, Cliente cliente, Tecnico tecnico, String titulo, String descricao, int prioridade, TipoChamado tipo) {
      Chamado chamado = new Chamado(data, cliente, tecnico, titulo, descricao, prioridade, tipo);
      chamados.add(chamado);
      return chamado;
    }

    @Override
    public ITipoChamado incluiTipoChamado(int codigo, String nome, String descricao) {
       TipoChamado tipoChamado = new TipoChamado(codigo, nome, descricao);
       tipoChamados.add(tipoChamado);
       return tipoChamado;
    }
    
}
