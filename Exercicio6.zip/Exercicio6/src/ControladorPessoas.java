
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class ControladorPessoas implements IControladorPessoas {
    
    private ArrayList<Cliente> clientes;
    private ArrayList<Tecnico> tecnicos;
    
    public ControladorPessoas() {
        this.clientes = new ArrayList<>();
        this.tecnicos = new ArrayList<>();
    }

    @Override
    public ArrayList<Cliente> getClientes() {
        return this.clientes;
    }

    @Override
    public ArrayList<Tecnico> getTecnicos() {
        return this.tecnicos;
    }

    @Override
    public IPessoa incluiCliente(int codigo, String nome) {
        Cliente cliente = new Cliente(codigo, nome);
        clientes.add(cliente);
        return cliente;
    }

    @Override
    public IPessoa incluiTecnico(int codigo, String nome) {
        Tecnico tecnico = new Tecnico(codigo, nome);
        tecnicos.add(tecnico);
        return tecnico;
    }
    
}
