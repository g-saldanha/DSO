/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class Pessoa implements IPessoa {
    
    private int codigo;
    private String nome;
    
    public Pessoa(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }

    @Override
    public int getCodigo() {
        return this.codigo;
    }

    @Override
    public String getNome() {
        return this.nome;
    }
    
    private void setCodigo(int codigo) {
        this.codigo = codigo;
    }
    
    private void setNome(String nome) {
        this.nome = nome;
    }
    
}
