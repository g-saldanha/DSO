
import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Caio
 */
public class Chamado implements IChamado {
    
    private Cliente cliente;
    private String descricao;
    private int prioridade;
    private Tecnico tecnico;
    private TipoChamado tipo;
    private String titulo;
    private Date data;
    
    public Chamado(Date data, Cliente cliente, Tecnico tecnico, String titulo, String descricao, int prioridade, TipoChamado tipo) {
        this.cliente = cliente;
        this.descricao = descricao;
        this.prioridade = prioridade;
        this.tecnico = tecnico;
        this.tipo = tipo;
        this.titulo = titulo;
        this.data = data;
    }

    @Override
    public Cliente getCliente() {
        return this.cliente;
    }

    @Override
    public String getDescricao() {
        return this.descricao;
    }

    @Override
    public int getPrioridade() {
        return this.prioridade;
    }

    @Override
    public Tecnico getTecnico() {
        return this.tecnico;
    }

    @Override
    public TipoChamado getTipo() {
        return this.tipo;
    }

    @Override
    public String getTitulo() {
        return this.titulo;
    }
    
}
